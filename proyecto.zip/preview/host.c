/* host.c - vista previa en PC: emula VRAM/PAL/OAM/IO y un PPU de modo 0 para volcar capturas (PPM).
 * Usa EXACTAMENTE el mismo codigo del juego (carpeta source) compilado con -DHOST. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../source/game.h"

u8 host_vram[0x18000];
u16 host_pal[0x200];
u16 host_oam[0x200];
u16 host_io[0x80];
u8 host_sram[0x8000];
u16 host_keys;

void vsync(void) {}
u16 keys_now(void) { return host_keys; }

static u32 rgb15(u16 c) {
  u32 r = (c & 31) << 3, g = ((c >> 5) & 31) << 3, b = ((c >> 10) & 31) << 3;
  r |= r >> 5; g |= g >> 5; b |= b >> 5;
  return (r << 16) | (g << 8) | b;
}
static int bg_pix(int bg, int x, int y) { /* devuelve indice de paleta o -1 */
  u16 cnt = host_io[(0x08 >> 1) + bg];
  int cb = (cnt >> 2) & 3, c256 = (cnt >> 7) & 1, sb = (cnt >> 8) & 31;
  int hofs = host_io[(0x10 >> 1) + bg * 2] & 511, vofs = host_io[(0x12 >> 1) + bg * 2] & 511;
  int px = (x + hofs) & 255, py = (y + vofs) & 255;
  int tx = px >> 3, ty = py >> 3;
  u16 e = *(u16 *)&host_vram[sb * 0x800 + (ty * 32 + tx) * 2];
  int tile = e & 0x3FF, hf = (e >> 10) & 1, vf = (e >> 11) & 1, pb = e >> 12;
  int ix = px & 7, iy = py & 7;
  if (hf) ix = 7 - ix;
  if (vf) iy = 7 - iy;
  if (c256) { int v = host_vram[cb * 0x4000 + tile * 64 + iy * 8 + ix]; return v ? v : -1; }
  int b = host_vram[cb * 0x4000 + tile * 32 + iy * 4 + (ix >> 1)];
  int v = (ix & 1) ? b >> 4 : b & 15;
  return v ? pb * 16 + v : -1;
}
static int spr_pix(int pri, int x, int y) {
  for (int i = 0; i < 128; i++) {
    u16 a0 = host_oam[i * 4], a1 = host_oam[i * 4 + 1], a2 = host_oam[i * 4 + 2];
    if ((a0 & 0x300) == 0x200) continue;
    if (((a2 >> 10) & 3) != pri) continue;
    int shape = a0 >> 14, size = a1 >> 14;
    static const int W[3][4] = {{8, 16, 32, 64}, {16, 32, 32, 64}, {8, 8, 16, 32}}, H[3][4] = {{8, 16, 32, 64}, {8, 8, 16, 32}, {16, 32, 32, 64}};
    int w = W[shape][size], h = H[shape][size];
    int sx = a1 & 511; if (sx >= 256) sx -= 512;
    int sy = a0 & 255; if (sy >= 160) sy -= 256;
    int lx = x - sx, ly = y - sy;
    if (lx < 0 || ly < 0 || lx >= w || ly >= h) continue;
    if (a1 & 0x1000) lx = w - 1 - lx;
    if (a1 & 0x2000) ly = h - 1 - ly;
    int c256 = (a0 >> 13) & 1, tile = a2 & 0x3FF, tpr = w / 8;
    int tx = lx >> 3, ty = ly >> 3, ix = lx & 7, iy = ly & 7;
    if (c256) {
      int t = tile + (ty * tpr + tx) * 2;
      int v = host_vram[0x10000 + t * 32 + iy * 8 + ix];
      if (v) return 256 + v;
    } else {
      int t = tile + ty * tpr + tx;
      int b = host_vram[0x10000 + t * 32 + iy * 4 + (ix >> 1)];
      int v = (ix & 1) ? b >> 4 : b & 15;
      if (v) return 256 + ((a2 >> 12) * 16 + v);
    }
  }
  return -1;
}
static u32 frame[240 * 160];
static int top_pix(int x, int y, int skip3, int *from3) {
  u16 dc = host_io[0];
  *from3 = 0;
  for (int pri = 0; pri < 4; pri++) {
    if (dc & 0x1000) { int s = spr_pix(pri, x, y); if (s >= 0) return s; }
    for (int bg = 0; bg < 4; bg++) {
      if (!(dc & (0x100 << bg))) continue;
      if (skip3 && bg == 3) continue;
      if ((host_io[(0x08 >> 1) + bg] & 3) != pri) continue;
      int p = bg_pix(bg, x, y);
      if (p >= 0) { if (bg == 3) *from3 = 1; return p; }
    }
  }
  return -1;
}
static void ppu_render(void) {
  u16 bld = host_io[0x50 >> 1], alpha = host_io[0x52 >> 1];
  int eva = alpha & 31, evb = (alpha >> 8) & 31; if (eva > 16) eva = 16; if (evb > 16) evb = 16;
  for (int y = 0; y < 160; y++)
    for (int x = 0; x < 240; x++) {
      int f3, col = top_pix(x, y, 0, &f3);
      u32 c = rgb15(col < 0 ? host_pal[0] : host_pal[col]);
      if (f3 && (bld & 0x0048) == 0x0048) { /* alpha: BG3 primer objetivo */
        int g; int c2 = top_pix(x, y, 1, &g);
        u32 d = rgb15(c2 < 0 ? host_pal[0] : host_pal[c2]);
        u32 r = (((c >> 16) & 255) * eva + ((d >> 16) & 255) * evb) / 16, gg = (((c >> 8) & 255) * eva + ((d >> 8) & 255) * evb) / 16, bb = ((c & 255) * eva + (d & 255) * evb) / 16;
        if (r > 255) r = 255; if (gg > 255) gg = 255; if (bb > 255) bb = 255;
        c = (r << 16) | (gg << 8) | bb;
      }
      frame[y * 240 + x] = c;
    }
}
static void shot(const char *name) {
  ppu_render();
  char path[256]; snprintf(path, sizeof path, "%s.ppm", name);
  FILE *f = fopen(path, "wb");
  fprintf(f, "P6\n240 160\n255\n");
  for (int i = 0; i < 240 * 160; i++) { fputc((frame[i] >> 16) & 255, f); fputc((frame[i] >> 8) & 255, f); fputc(frame[i] & 255, f); }
  fclose(f);
}
static void step(int n, u16 keys) { for (int i = 0; i < n; i++) { host_keys = keys; game_frame(); } host_keys = 0; }
static void tp(int x, int y) { P.x = x * 256 + 128; P.y = y * 256 + 128; render_full_redraw(); }

/* mapa completo de la superficie para ajustar la generacion */
static void dump_world(const char *name) {
  FILE *f = fopen(name, "wb");
  fprintf(f, "P6\n128 128\n255\n");
  int save = cur_dim; cur_dim = D_OVER;
  for (int y = 0; y < 128; y++) for (int x = 0; x < 128; x++) {
    u8 g = getg(x, y), o = geto(x, y);
    int r = 90, gg = 160, b = 60;
    switch (g) { case G_WATER: r = 40; gg = 90; b = 200; break; case G_DEEP: r = 20; gg = 50; b = 150; break; case G_SAND: r = 225; gg = 205; b = 140; break; case G_SNOW: r = 240; gg = 240; b = 250; break; case G_JGRASS: r = 30; gg = 120; b = 30; break; case G_DIRT: r = 130; gg = 90; b = 50; break; case G_PATH: r = 190; gg = 150; b = 100; break; case G_WOOD: r = 150; gg = 110; b = 60; break; case G_SOIL: case G_SOILW: r = 100; gg = 60; b = 30; break; default: break; }
    if (o == O_MTN) { r = gg = b = 110; }
    else if (o == O_TREE || o == O_PINE || o == O_JTREE) { r = 20; gg = 90; b = 20; }
    else if (o == O_PLANK) { r = 200; gg = 140; b = 60; }
    else if (o == O_DOOR) { r = 255; gg = 0; b = 0; }
    fputc(r, f); fputc(gg, f); fputc(b, f);
  }
  cur_dim = save;
  fclose(f);
}

int main(int argc, char **argv) {
  const char *out = argc > 1 ? argv[1] : ".";
  char p[300];
#define SHOT(n) do { snprintf(p, sizeof p, "%s/%s", out, n); shot(p); } while (0)
  game_init();
  step(30, 0);
  SHOT("01_titulo");
  /* nueva partida de supervivencia */
  step(1, KEY_A);
  step(5, 0);
  game_time = 0; day_t = 3000;
  /* equipamiento de demostracion */
  inv_add(I_SPICK, 1); inv_add(I_ISWORD, 1); inv_add(I_BOW, 1); inv_add(I_ARROW, 24); inv_add(I_COBBLE, 40); inv_add(I_PLANK, 20);
  inv_add(I_APPLE, 5); inv_add(I_IRON, 12); inv_add(I_COAL, 9); inv_add(I_REDSTONE, 30); inv_add(I_PISTON, 2); inv_add(I_LAMP, 3); inv_add(I_LEVER, 2);
  inv_add(I_DIAMOND, 3); inv_add(I_BUCKET, 1); inv_add(I_HOE, 1); inv_add(I_SEED, 8); inv_add(I_LAPIS, 5); inv_add(I_ENCH, 1);
  P.xp = 7; P.lvl = 4; P.hp = 15; P.food = 17;
  { char wp[300]; snprintf(wp, sizeof wp, "%s/mundo.ppm", out); dump_world(wp); }
  step(10, 0);
  SHOT("02_spawn");
  /* aldea */
  if (vill_n > 0) { tp(vill_pt[0].x, vill_pt[0].y); P.sel = 1; step(90, 0); SHOT("03_aldea"); }
  /* puertas / colinas */
  tp(door_pt[0].x, door_pt[0].y + 3); step(20, 0); SHOT("04_colinas");
  /* noche */
  day_t = DAY_LEN * 72 / 100; seto(PTX() + 1, PTY() + 2, O_TORCH); step(40, 0); SHOT("05_noche");
  day_t = DAY_LEN * 56 / 100; step(3, 0); SHOT("05b_atardecer");
  day_t = 3000;
  /* cuevas */
  change_dim(D_CAVE, exit_pt[0].x, exit_pt[0].y + 2);
  step(60, 0); SHOT("06_cueva");
  /* fortaleza del End (cofres, marco) */
  tp(44, 46); step(60, 0); SHOT("07_fortaleza");
  /* nether */
  change_dim(D_NETH, spawn_pt[D_NETH].x, spawn_pt[D_NETH].y);
  step(80, 0); SHOT("08_nether");
  tp(34, 14); step(60, 0); SHOT("09_fortaleza_nether");
  /* end */
  change_dim(D_END, spawn_pt[D_END].x, spawn_pt[D_END].y);
  step(120, 0); SHOT("10_end");
  for (int i = 0; i < MAXENT; i++) if ((ents[i].flags & EF_ALIVE) && ents[i].type == M_DRAGON) { tp((ents[i].x >> 8), (ents[i].y >> 8) + 4); break; }
  step(8, 0); SHOT("10b_dragon");
  /* menus */
  change_dim(D_OVER, spawn_pt[D_OVER].x, spawn_pt[D_OVER].y); step(5, 0);
  ui_open(MN_INV, 0); step(2, 0); SHOT("11_inventario");
  ui_open(MN_CRAFT, 0); step(2, KEY_RIGHT); step(1, 0); step(2, KEY_RIGHT); step(1,0); SHOT("12_fabricar");
  ui_open(MN_PAUSE, 0); step(2, KEY_DOWN); SHOT("13_pausa");
  ui_open(MN_MAP, 0); step(20, 0); SHOT("14_mapa");
  ui_open(MN_ENCH, 0); step(2, 0); SHOT("15_encantar");
  trade_ent = 0; ui_open(MN_TRADE, 3); step(2, 0); SHOT("16_comercio");
  menu_kind = MN_NONE; render_full_redraw();
  /* redstone: palanca -> cable -> lampara */
  tp(spawn_pt[D_OVER].x, spawn_pt[D_OVER].y);
  int bx = PTX() + 2, by = PTY();
  seto(bx, by, O_LEVER); seto(bx + 1, by, O_WIRE); seto(bx + 2, by, O_WIRE); seto(bx + 3, by, O_LAMP);
  rs_neighbor_changed(bx, by);
  P.dir = 3; P.sel = 0; step(30, 0);
  wst[tidx(bx, by)] |= 0x80; render_tile(bx, by); step(40, 0);
  SHOT("17_redstone");
  /* combate con mobs */
  ents_clear();
  ent_spawn(M_ZOMBIE, PTX() + 3, PTY() - 2); ent_spawn(M_CREEPER, PTX() - 3, PTY() + 2); ent_spawn(M_SKELETON, PTX() - 4, PTY() - 3);
  ent_spawn(M_COW, PTX() + 4, PTY() + 3); ent_spawn(M_SHEEP, PTX() - 2, PTY() + 4);
  step(20, 0); SHOT("18_mobs");
  P.dir = 3; P.swing = 5; step(1, 0); SHOT("19_golpe");
  for (int k = 0; k < 4; k++) { P.dir = 3; P.swing = 9 - k * 2 + 1; step(1, 0); { char nm[32]; snprintf(nm, sizeof nm, "19_golpe%d", k); SHOT(nm); } }
  /* guardar y cargar */
  save_game(0);
  printf("save ok: exists=%d\n", save_exists(0));
  int ok = load_game(0);
  printf("load ok=%d dim=%d hp=%d lvl=%d\n", ok, cur_dim, P.hp, P.lvl);
  printf("vill_n=%d doors=%d,%d %d,%d %d,%d\n", vill_n, door_pt[0].x, door_pt[0].y, door_pt[1].x, door_pt[1].y, door_pt[2].x, door_pt[2].y);
  return 0;
}
