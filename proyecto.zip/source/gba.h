/* gba.h - capa minima de hardware (sin libgba, sin libc).
 * En GBA real usa las direcciones de memoria; con -DHOST (vista previa en PC)
 * usa arrays que emulan VRAM/PAL/OAM/IO para renderizar capturas. */
#ifndef GBA_H
#define GBA_H

typedef unsigned char u8;
typedef signed char s8;
typedef unsigned short u16;
typedef signed short s16;
typedef unsigned int u32;
typedef signed int s32;

#ifdef HOST
extern u8 host_vram[0x18000];
extern u16 host_pal[0x200];
extern u16 host_oam[0x200];
extern u16 host_io[0x80];
extern u8 host_sram[0x8000];
extern u16 host_keys;
#define VRAM8 ((volatile u8 *)host_vram)
#define VRAM16 ((volatile u16 *)host_vram)
#define PAL ((volatile u16 *)host_pal)
#define OAM16 ((volatile u16 *)host_oam)
#define IOR(o) (host_io[(o) >> 1])
#define SRAM ((volatile u8 *)host_sram)
#define EWRAM
#define IWRAM_CODE
#else
#define VRAM8 ((volatile u8 *)0x06000000)
#define VRAM16 ((volatile u16 *)0x06000000)
#define PAL ((volatile u16 *)0x05000000)
#define OAM16 ((volatile u16 *)0x07000000)
#define IOR(o) (*(volatile u16 *)(0x04000000 + (o)))
#define SRAM ((volatile u8 *)0x0E000000)
#define EWRAM __attribute__((section(".sbss")))
#define IWRAM_CODE __attribute__((section(".iwram"), long_call))
#endif

#define OBJ_VRAM_OFF 0x10000 /* bytes: 0x06010000 */

#define REG_DISPCNT IOR(0x00)
#define REG_VCOUNT IOR(0x06)
#define REG_BG0CNT IOR(0x08)
#define REG_BG1CNT IOR(0x0A)
#define REG_BG2CNT IOR(0x0C)
#define REG_BG3CNT IOR(0x0E)
#define REG_BG0HOFS IOR(0x10)
#define REG_BG0VOFS IOR(0x12)
#define REG_BG1HOFS IOR(0x14)
#define REG_BG1VOFS IOR(0x16)
#define REG_BG2HOFS IOR(0x18)
#define REG_BG2VOFS IOR(0x1A)
#define REG_BG3HOFS IOR(0x1C)
#define REG_BG3VOFS IOR(0x1E)
#define REG_BLDCNT IOR(0x50)
#define REG_BLDALPHA IOR(0x52)
#define REG_BLDY IOR(0x54)
#define REG_KEYINPUT IOR(0x130)
#define REG_WAITCNT IOR(0x204)

#define KEY_A 0x001
#define KEY_B 0x002
#define KEY_SELECT 0x004
#define KEY_START 0x008
#define KEY_RIGHT 0x010
#define KEY_LEFT 0x020
#define KEY_UP 0x040
#define KEY_DOWN 0x080
#define KEY_R 0x100
#define KEY_L 0x200

#define DCNT_MODE0 0
#define DCNT_OBJ_1D 0x0040
#define DCNT_BG0 0x0100
#define DCNT_BG1 0x0200
#define DCNT_BG2 0x0400
#define DCNT_BG3 0x0800
#define DCNT_OBJ 0x1000

#define SCREEN_W 240
#define SCREEN_H 160

/* BGxCNT: prioridad | charbase<<2 | 256 colores (1<<7) | screenbase<<8 | tamano<<14 */
#define BGCNT(pri, cb, c256, sb, sz) ((pri) | ((cb) << 2) | ((c256) << 7) | ((sb) << 8) | ((sz) << 14))

void vsync(void);
u16 keys_now(void);

static inline void mcpy16(volatile u16 *d, const u16 *s, int n) {
  while (n-- > 0) *d++ = *s++;
}

#endif
