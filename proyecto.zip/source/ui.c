/* ui.c - render del mundo, HUD y menus (inventario, fabricar, cofre, comercio, encantar, mapa...) */
#include "game.h"

int menu_kind;
Ent *trade_ent;
static int mcur, mtop, mpane, marg, mcat, msel2, mredraw, mrep;
static int cur2, top2; /* segundo panel (cofre) */
/* sprites de menu */
static int mn_title, mn_bx0, mn_bx1, mn_by, mn_bh, mn_icn;
static struct { s16 x, y; u8 id; } mn_ic[10];
static u8 mic_cache[10];
static void mn_reset(void);

/* ------------------------------------------------------------------ texto */
void hud_clear(void) {
  for (int i = 0; i < 1024; i++) map_hud[i] = 0;
  map_dirty |= 8;
}
void hud_fill_panel(void) {
  for (int i = 0; i < 1024; i++) map_hud[i] = T_PANEL | (15 << 12);
  map_dirty |= 8;
}
static void hud_tile(int x, int y, int t) {
  if (x < 0 || y < 0 || x >= 30 || y >= 20) return;
  map_hud[y * 32 + x] = (u16)(t | (15 << 12));
  map_dirty |= 8;
}
void hud_text(int x, int y, const char *s) {
  while (*s && x < 30) {
    int c = (unsigned char)*s++;
    hud_tile(x++, y, (c >= 32 && c < 127) ? T_CHAR(c) : T_BLANK);
  }
}
static int itoa_(char *b, int v) {
  char t[12]; int n = 0, k = 0;
  if (v < 0) { b[k++] = '-'; v = -v; }
  if (v == 0) t[n++] = '0';
  while (v) { t[n++] = (char)('0' + v % 10); v /= 10; }
  while (n) b[k++] = t[--n];
  b[k] = 0;
  return k;
}
static void hud_num(int x, int y, int v) { char b[12]; itoa_(b, v); hud_text(x, y, b); }
static int slen(const char *s) { int n = 0; while (s[n]) n++; return n; }
static void padtext(char *dst, const char *s, int w) {
  int i = 0;
  while (s[i] && i < w) { dst[i] = s[i]; i++; }
  while (i < w) dst[i++] = ' ';
  dst[w] = 0;
}
static const char *ROMAN[4] = {"", "I", "II", "III"};

/* ------------------------------------------------------------------ mundo */
static int win_valid, wx0, wy0;
static int cam_x, cam_y;
static int scr_x, scr_y;
static int dark_tx, dark_ty, dark_t = -999, dark_amb = -1;

static void draw_cell(int tx, int ty) {
  int gs = 0, os = 0, hf = 0, vf = 0;
  if (tx >= 0 && ty >= 0 && tx < MW && ty < MH) {
    int i = tidx(tx, ty);
    gs = gfx_ground_slot(wg[i]);
    if (wg[i] == G_VOID) gs = 0;
    u8 o = wo[i];
    if (o) { u8 h2, v2; os = gfx_obj_slot(o, (u8)(wst[i] >> 7), (u8)(wst[i] & 3), &h2, &v2); hf = h2; vf = v2; }
  }
  mt_put(map_gnd, tx, ty, gs, 0, 0);
  mt_put(map_obj, tx, ty, os, hf, vf);
}
void render_tile(int x, int y) {
  if (!win_valid) return;
  if (x >= wx0 && x < wx0 + 16 && y >= wy0 && y < wy0 + 16) draw_cell(x, y);
  dark_t = -999;
}
void render_full_redraw(void) { win_valid = 0; dark_t = -999; }

static int clampi(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }

static void apply_light(u8 *red, int cx0, int cy0, int lx, int ly, int r) {
  int y0 = ly - r < cy0 ? cy0 : ly - r, y1 = ly + r > cy0 + 11 ? cy0 + 11 : ly + r;
  int x0 = lx - r < cx0 ? cx0 : lx - r, x1 = lx + r > cx0 + 15 ? cx0 + 15 : lx + r;
  for (int y = y0; y <= y1; y++)
    for (int x = x0; x <= x1; x++) {
      int dx = x - lx, dy = y - ly, q = dx * dx + dy * dy, rd = 0;
      if (q <= r * r / 4) rd = 3; else if (q <= r * r * 9 / 16) rd = 2; else if (q <= r * r) rd = 1;
      u8 *p = &red[(y - cy0) * 16 + (x - cx0)];
      if (rd > *p) *p = (u8)rd;
    }
}
/* tinte de color segun la hora (amanecer, atardecer, noche azulada) y la dimension */
static const s16 TINT_K[8][4] = {{0, 32, 32, 32}, {500, 32, 32, 32}, {580, 32, 27, 21}, {660, 25, 24, 29}, {720, 20, 23, 30}, {840, 20, 23, 30}, {920, 30, 26, 26}, {1000, 32, 32, 32}};
void ui_update_tint(int neutral) {
  int r = 32, g = 32, b = 32;
  if (neutral) { gfx_tint(r, g, b); return; }
  if (cur_dim == D_OVER) {
    int p = (int)(day_t * 1000 / DAY_LEN);
    for (int k = 0; k < 7; k++)
      if (p >= TINT_K[k][0] && p <= TINT_K[k + 1][0]) {
        int span = TINT_K[k + 1][0] - TINT_K[k][0], f = p - TINT_K[k][0];
        r = TINT_K[k][1] + (TINT_K[k + 1][1] - TINT_K[k][1]) * f / span;
        g = TINT_K[k][2] + (TINT_K[k + 1][2] - TINT_K[k][2]) * f / span;
        b = TINT_K[k][3] + (TINT_K[k + 1][3] - TINT_K[k][3]) * f / span;
        break;
      }
  } else if (cur_dim == D_CAVE) { r = 28; g = 30; b = 32; }
  else if (cur_dim == D_NETH) { r = 32; g = 25; b = 22; }
  else { r = 27; g = 25; b = 32; }
  gfx_tint(r, g, b);
}

static void update_dark(int cx0, int cy0) {
  int amb = dark_level_ambient();
  int ptx = PTX(), pty = PTY();
  if (!(amb != dark_amb || ptx != dark_tx || pty != dark_ty || (int)game_time - dark_t > 30 || dark_t == -999)) return;
  dark_amb = amb; dark_tx = ptx; dark_ty = pty; dark_t = (int)game_time;
  static u8 red[16 * 12];
  for (int i = 0; i < 16 * 12; i++) red[i] = 0;
  if (amb > 0) {
    for (int y = cy0 - 6; y < cy0 + 18; y++)
      for (int x = cx0 - 6; x < cx0 + 22; x++) {
        if (x < 0 || y < 0 || x >= MW || y >= MH) continue;
        int i = tidx(x, y);
        u8 o = wo[i];
        int r = o ? BLK[o].light : 0;
        if (o == O_LAMP && !(wst[i] & 0x80)) r = 0;
        if (!r && wg[i] == G_LAVA && cur_dim != D_OVER) r = 3;
        if (r) apply_light(red, cx0, cy0, x, y, r);
      }
    apply_light(red, cx0, cy0, ptx, pty, P.t_night > 0 ? 9 : 4);
  }
  for (int cy = cy0; cy < cy0 + 12; cy++)
    for (int cx = cx0; cx < cx0 + 16; cx++) {
      int d = amb - red[(cy - cy0) * 16 + (cx - cx0)];
      if (d < 0) d = 0;
      u16 e = d ? (u16)((T_DARK1 + d - 1) | (15 << 12)) : 0;
      u16 *p = &map_dark[((cy & 15) * 2) * 32 + (cx & 15) * 2];
      p[0] = e; p[1] = e; p[32] = e; p[33] = e;
    }
  map_dirty |= 4;
}

static int spr_n;
static void spr(int x, int y, int slot, int size, int hf, int vf, int pri) { spr_n = oam_put(spr_n, x, y, slot, size, hf, vf, pri); }

static u8 hb_cache[9] = {255, 255, 255, 255, 255, 255, 255, 255, 255};

void ui_draw_hud(void) {
  /* corazones */
  for (int i = 0; i < 10; i++) {
    int v = P.hp - i * 2;
    hud_tile(i, 0, T_HEART + (v >= 2 ? 0 : v == 1 ? 1 : 2));
    int f = P.food - i * 2;
    hud_tile(20 + i, 0, T_FOOD + (f >= 2 ? 0 : f == 1 ? 1 : 2));
  }
  /* nivel y xp */
  hud_text(0, 1, "Nv");
  hud_num(2, 1, P.lvl);
  int fill = P.xp * 6 / xp_need(P.lvl);
  for (int i = 0; i < 6; i++) hud_tile(6 + i, 1, i < fill ? T_XPON : T_XPOFF);
  /* hora */
  {
    int hh = (int)((day_t * 24 / DAY_LEN + 6) % 24), mm = (int)((day_t * 24 * 60 / DAY_LEN) % 60);
    char b[8] = {(char)('0' + hh / 10), (char)('0' + hh % 10), ':', (char)('0' + mm / 10), (char)('0' + mm % 10), 0};
    hud_text(25, 1, b);
  }
  /* modo */
  if (P.mode == MODE_CREATIVE) hud_text(13, 1, "CREATIVO");
  else if (P.mode == MODE_HARD) hud_text(13, 1, "HARDCORE");
  /* jefe */
  if (boss && boss->type == M_DRAGON) {
    hud_text(8, 2, "DRAGON");
    int n = boss->hp * 12 / 60 + (boss->hp ? 1 : 0);
    for (int i = 0; i < 12; i++) hud_tile(15 + i, 2, i < n ? T_HEART : T_HEART + 2);
  }
  /* mensaje */
  if (msg_t > 0) { msg_t--; hud_text(0, 16, msg_buf); }
  /* hotbar: 9 cajas de 3x3 tiles (24x24 px); la seleccionada con marco dorado */
  for (int i = 0; i < 9; i++) {
    int base = (i == P.sel) ? T_SLOTSEL : T_SLOT;
    for (int cy = 0; cy < 3; cy++) for (int cx = 0; cx < 3; cx++) hud_tile(1 + i * 3 + cx, 17 + cy, base + cy * 3 + cx);
    if (inv[i].id != hb_cache[i]) { hb_cache[i] = inv[i].id; gfx_icon(S_ICON + i, inv[i].id); }
  }
}

void render_world(void) {
  cam_x = clampi(PX() - 120, 0, MW * 16 - 240);
  cam_y = clampi(PY() - 80, 0, MH * 16 - 160);
  int cx0 = cam_x >> 4, cy0 = cam_y >> 4;
  if (!win_valid || cx0 - wx0 > 1 || wx0 - cx0 > 1 || cy0 - wy0 > 1 || wy0 - cy0 > 1) {
    for (int y = cy0; y < cy0 + 16; y++) for (int x = cx0; x < cx0 + 16; x++) draw_cell(x, y);
    win_valid = 1; wx0 = cx0; wy0 = cy0; dark_t = -999;
  } else {
    while (wx0 < cx0) { for (int y = wy0; y < wy0 + 16; y++) draw_cell(wx0 + 16, y); wx0++; }
    while (wx0 > cx0) { wx0--; for (int y = wy0; y < wy0 + 16; y++) draw_cell(wx0, y); }
    while (wy0 < cy0) { for (int x = wx0; x < wx0 + 16; x++) draw_cell(x, wy0 + 16); wy0++; }
    while (wy0 > cy0) { wy0--; for (int x = wx0; x < wx0 + 16; x++) draw_cell(x, wy0); }
  }
  update_dark(cx0, cy0);
  scr_x = cam_x & 255; scr_y = cam_y & 255;
  /* sprites */
  oam_clear(); spr_n = 0;
  int bob = (P.moving && ((P.anim >> 3) & 1)) ? 1 : 0;
  int ppx = PX() - cam_x - 8, ppy = PY() - cam_y - 10;
  if (P.swing > 0) { /* tajo animado (4 frames) */
    int k = (8 - P.swing) >> 1; if (k < 0) k = 0; if (k > 3) k = 3;
    switch (P.dir) {
    case 3: spr(ppx + 15, ppy + 2, S_SLASH + k, 1, 0, 0, 0); break;
    case 1: spr(ppx - 15, ppy + 2, S_SLASH + k, 1, 1, 0, 0); break;
    case 0: spr(ppx, ppy + 17, S_SLASHV + k, 1, 0, 0, 0); break;
    default: spr(ppx, ppy - 12, S_SLASHV + k, 1, 0, 1, 0); break;
    }
  }
  if (!(P.hurt > 0 && (P.hurt & 4)) && !P.sleeping) {
    int lunge = P.swing > 5 ? 2 : P.swing > 2 ? 1 : 0; /* el jugador se inclina hacia el golpe */
    int px0 = ppx + DX[P.dir] * lunge, py0 = ppy + DY[P.dir] * lunge;
    int rise = P.fly ? 5 + ((game_time >> 4) & 1) : 0;
    if (P.fly) spr(ppx, ppy + 4, S_SHADOW, 1, 0, 0, 1);
    spr(px0, py0 - 16 - rise, S_PLAYER + (P.dir * 2 + bob) * 2, 3, 0, 0, 0);
    if (P.boat) spr(ppx, ppy + 3, S_BOAT, 1, 0, 0, 0);
  }
  if (P.sleeping) spr(ppx, ppy - 12, S_PLAYER + 8, 3, 0, 0, 0);
  if (P.fish_t != 0) spr(P.fish_x * 16 - cam_x, P.fish_y * 16 - cam_y, S_SPARK, 1, 0, 0, 2);
  for (int i = 0; i < MAXENT; i++) {
    Ent *e = &ents[i];
    if (!(e->flags & EF_ALIVE)) continue;
    const MobInfo *m = &MOBS[e->type];
    int sx = (e->x >> 4) - cam_x, sy = (e->y >> 4) - cam_y;
    if (e->hurt > 0 && (e->hurt & 2)) continue;
    int f = ((e->anim >> 3) & 1);
    if (e->flags & EF_FUSE) { if (e->t2 & 4) continue; }
    if (e->type == M_GHAST) spr(sx - 16, sy - 16, S_GHAST, 2, 0, 0, 2);
    else if (e->type == M_DRAGON) spr(sx - 16, sy - 16, S_DRAGON + f * 4, 2, e->dir == 3, 0, 2);
    else {
      u8 hf, tall;
      int walking = MOBS[e->type].fly ? (e->st != 0) : e->stp;
      int sl = gfx_mob_slot(e->type, e->dir, walking ? f : 0, &hf, &tall);
      if (tall) spr(sx - 8, sy - 26, sl, 3, hf, 0, 2); else spr(sx - 8, sy - 10, sl, 1, hf, 0, 2);
    }
  }
  for (int i = 0; i < 6; i++)
    if (fxs[i].t > 0) spr((fxs[i].x >> 4) - cam_x - 8, (fxs[i].y >> 4) - cam_y - 8, S_HIT + (9 - fxs[i].t) / 3, 1, 0, 0, 1);
  for (int i = 0; i < MAXPROJ; i++) {
    Proj *p = &projs[i];
    if (!p->type) continue;
    int sx = (p->x >> 4) - cam_x - 8, sy = (p->y >> 4) - cam_y - 8;
    if (p->type == 2) spr(sx, sy, S_FIRE, 1, 0, 0, 2);
    else spr(sx, sy, p->dir & 1 ? S_ARROWH : S_ARROW, 1, p->dir == 3, p->dir == 0, 2);
  }
  for (int i = 0; i < 6; i++)
    if (booms[i].t > 0) {
      int sx = (booms[i].x >> 4) - cam_x - 8, sy = (booms[i].y >> 4) - cam_y - 8, t = booms[i].t;
      spr(sx - t, sy, S_FIRE, 1, 0, 0, 0); spr(sx + t, sy, S_FIRE, 1, 0, 0, 0); spr(sx, sy - t, S_FIRE, 1, 0, 0, 0); spr(sx, sy + t, S_FIRE, 1, 0, 0, 0); spr(sx, sy, S_FIRE, 1, 0, 0, 0);
    }
  /* hotbar: iconos y seleccion */
  hud_clear();
  ui_draw_hud();
  for (int i = 0; i < 9; i++) {
    if (!inv[i].id) continue;
    int bx = 8 + i * 24;
    const Slot *sl = &inv[i];
    if (sl->n > 1) { /* cantidad (decenas y unidades) sobre el icono */
      int n = sl->n > 99 ? 99 : sl->n;
      spr_n = oam_put_raw(spr_n, bx + 15, 150, (S_DIG * 8) + (n % 10) * 2, 0, 0, 0, 0);
      if (n >= 10) spr_n = oam_put_raw(spr_n, bx + 9, 150, (S_DIG * 8) + (n / 10) * 2, 0, 0, 0, 0);
    }
    int mx = ITM[sl->id].dur;
    if (mx && sl->dur < mx) { /* barra de durabilidad */
      int lv = (sl->dur * 8 + mx - 1) / mx; if (lv < 1) lv = 1; if (lv > 8) lv = 8;
      spr_n = oam_put_raw(spr_n, bx + 4, 157, (S_DUR * 8) + (lv - 1) * 4, 6, 0, 0, 0);
    }
    spr(bx + 4, 140, S_ICON + i, 1, 0, 0, 0);
  }
}

/* ------------------------------------------------------------------- menus */
static void scroll_fix(int *cur, int *top, int count, int rows) {
  if (*cur < 0) *cur = count - 1;
  if (*cur >= count) *cur = 0;
  if (*cur < *top) *top = *cur;
  if (*cur >= *top + rows) *top = *cur - rows + 1;
  if (*top < 0) *top = 0;
}
static void fmt_slot(char *b, const Slot *s, int w) {
  char t[34];
  int k = 0;
  const char *nm = s->id ? item_name(s->id) : "-";
  while (nm[k] && k < w - 4) { t[k] = nm[k]; k++; }
  if (s->id && s->en) { t[k++] = '*'; }
  t[k] = 0;
  padtext(b, t, w);
  if (s->id && s->n > 1) { char n[8]; int l = itoa_(n, s->n); for (int i = 0; i < l; i++) b[w - l + i] = n[i]; }
}

static const char *PAUSE_ITEMS[] = {"Continuar", "Inventario", "Fabricar", "Mapa", "Logros", "Ayuda", "Guardar ranura 1", "Guardar ranura 2", "Objetos (creativo)", "Volar (creativo)", "Salir al titulo"};
#define PAUSE_N 11
static u8 cre_list[I_COUNT];
static int cre_n;

void ui_open(int kind, int arg) {
  menu_kind = kind; mcur = 0; mtop = 0; mpane = 0; marg = arg; mcat = 0; mredraw = 1; cur2 = top2 = 0; msel2 = -1;
  if (kind == MN_CRAFT) mcat = arg == 11 ? 11 : 0;
  if (kind == MN_CREATIVE) { cre_n = 0; for (int i = 1; i < I_COUNT; i++) if (ITM[i].name) cre_list[cre_n++] = (u8)i; }
  for (int i = 0; i < 9; i++) hb_cache[i] = 255;
  for (int i = 0; i < 10; i++) mic_cache[i] = 0;
  mn_reset();
  oam_clear(); oam_flush();
}
void ui_trade_open(Ent *e) { trade_ent = e; ui_open(MN_TRADE, e->aux % 5); }

static void close_menu(void) { menu_kind = MN_NONE; render_full_redraw(); for (int i = 0; i < 9; i++) hb_cache[i] = 255; hud_clear(); }
static void back_to_pause(void) { ui_open(MN_PAUSE, 0); }

/* ---- estado de los sprites de menu (barras de titulo/seleccion e iconos) ---- */

static void hud_tile_b(int x, int y, int t, int bank) {
  if (x < 0 || y < 0 || x >= 30 || y >= 20) return;
  map_hud[y * 32 + x] = (u16)(t | (bank << 12));
  map_dirty |= 8;
}
static void hud_dim(int x, int y, const char *s) { /* texto apagado (banco de paleta 13) */
  while (*s && x < 30) { int c = (unsigned char)*s++; hud_tile_b(x++, y, (c >= 32 && c < 127) ? T_CHAR(c) : T_BLANK, 13); }
}
static void hud_txt2(int x, int y, const char *s, int dim) { if (dim) hud_dim(x, y, s); else hud_text(x, y, s); }
static void hud_blank(int x0, int y, int x1, int h) {
  for (int j = 0; j < h; j++) for (int x = x0; x < x1; x++) hud_tile(x, y + j, T_BLANK);
}
static void mn_reset(void) { mn_title = 0; mn_bh = 0; mn_icn = 0; }
static void chrome(const char *t) {
  hud_fill_panel();
  mn_reset();
  mn_title = 1;
  hud_blank(0, 0, 30, 1);
  hud_text(1, 0, t);
  for (int x = 0; x < 30; x++) hud_tile(x, 1, T_BORDER);
}
static void chrome_foot(void) { for (int x = 0; x < 30; x++) hud_tile(x, 16, T_BORDER); }
static void mn_bar(int x0, int x1, int ty, int h) { /* barra de seleccion detras del texto (x0,x1 en px) */
  mn_bx0 = x0; mn_bx1 = x1; mn_by = ty * 8; mn_bh = h;
  hud_blank(x0 / 8, ty, x1 / 8, h / 8);
}
static void mn_icon(int x, int y, int id) { if (id && mn_icn < 10) { mn_ic[mn_icn].x = (s16)x; mn_ic[mn_icn].y = (s16)y; mn_ic[mn_icn].id = (u8)id; mn_icn++; } }
static void mn_count(int cur, int tot) { char b[12]; int k = itoa_(b, cur + 1); b[k++] = '/'; k += itoa_(b + k, tot); b[k] = 0; hud_text(29 - k, 0, b); }

void ui_menu_sprites(void) {
  int n = 0;
  if (mn_title) for (int k = 0; k < 8; k++) n = oam_put(n, k * 32, 0, S_BART, 4, 0, 0, 1);
  if (mn_bh) {
    int x = mn_bx0;
    for (; x + 32 <= mn_bx1; x += 32) n = oam_put(n, x, mn_by, S_BAR, mn_bh == 16 ? 5 : 4, 0, 0, 1);
    if (x + 16 <= mn_bx1) n = oam_put(n, x, mn_by, S_BAR, mn_bh == 16 ? 1 : 6, 0, 0, 1);
  }
  for (int i = 0; i < mn_icn; i++) {
    int slot = i < 9 ? i : i == 9 ? 10 : 11;
    if (mic_cache[i] != mn_ic[i].id) { gfx_icon(slot, mn_ic[i].id); mic_cache[i] = mn_ic[i].id; }
    n = oam_put(n, mn_ic[i].x, mn_ic[i].y, slot, 1, 0, 0, 0);
  }
}

static int cat_count(int cat) { int n = 0; for (int i = 0; i < RECIPE_N; i++) if (RECIPES[i].cat == cat) n++; return n; }
static const Recipe *cat_recipe(int cat, int k) { for (int i = 0; i < RECIPE_N; i++) if (RECIPES[i].cat == cat) { if (!k--) return &RECIPES[i]; } return 0; }

static void draw_recipe_need(const Recipe *r) {
  const u8 ids[4] = {r->i1, r->i2, r->i3, r->i4}, ns[4] = {r->n1, r->n2, r->n3, r->n4};
  int slot = 0;
  for (int i = 0; i < 4; i++) {
    if (!ids[i]) continue;
    char t[34]; int l = 0;
    l += itoa_(t + l, ns[i]);
    t[l++] = ' ';
    const char *nm = item_name(ids[i]);
    for (int q = 0; nm[q] && q < 11; q++) t[l++] = nm[q];
    t[l] = 0;
    hud_txt2(1 + (slot & 1) * 14, 17 + (slot >> 1), t, inv_count(ids[i]) < ns[i] && P.mode != MODE_CREATIVE);
    slot++;
  }
}
/* resumen corto de ingredientes para la fila de la receta */
static void recipe_brief(char *b, const Recipe *r) {
  const u8 ids[4] = {r->i1, r->i2, r->i3, r->i4}, ns[4] = {r->n1, r->n2, r->n3, r->n4};
  int l = 0;
  for (int i = 0; i < 4 && l < 20; i++) {
    if (!ids[i]) continue;
    if (l) { b[l++] = ','; b[l++] = ' '; }
    l += itoa_(b + l, ns[i]);
    b[l++] = ' ';
    const char *nm = item_name(ids[i]);
    for (int q = 0; nm[q] && q < 7; q++) b[l++] = nm[q];
  }
  if (l > 22) l = 22;
  b[l] = 0;
}

static void draw_menu(void) {
  char buf[40];
  switch (menu_kind) {
  case MN_PAUSE:
    chrome("PAUSA");
    mn_bar(8, 232, 3 + mcur, 8);
    for (int i = 0; i < PAUSE_N; i++) hud_txt2(3, 3 + i, PAUSE_ITEMS[i], (i == 8 || i == 9) && P.mode != MODE_CREATIVE);
    hud_text(1, 3 + mcur, ">");
    chrome_foot();
    hud_text(1, 17, "A: elegir   B/Start: volver");
    hud_text(1, 18, "L/R: cambiar casilla de mano");
    break;
  case MN_INV:
    chrome("INVENTARIO");
    mn_count(mcur, INV_N);
    for (int r = 0; r < 7; r++) {
      int i = mtop + r, ty = 2 + r * 2;
      if (i >= INV_N) break;
      const Slot *sl = &inv[i];
      if (i == mcur) mn_bar(8, 232, ty, 16);
      if (sl->id) {
        mn_icon(16, ty * 8, sl->id);
        int k = 0;
        const char *nm = item_name(sl->id);
        while (nm[k] && k < 18) { buf[k] = nm[k]; k++; }
        buf[k] = 0;
        hud_text(5, ty, buf);
        if (sl->en) { int l = 0; const char *en = ENCH_NAMES[EN_T(sl)]; while (en[l] && l < 12) { buf[l] = en[l]; l++; } buf[l++] = ' '; const char *rm = ROMAN[EN_L(sl)]; for (int q = 0; rm[q]; q++) buf[l++] = rm[q]; buf[l] = 0; hud_text(5, ty + 1, buf); }
        else if (ITM[sl->id].dur) { int l = 0; buf[l++] = 'D'; buf[l++] = 'u'; buf[l++] = 'r'; buf[l++] = ' '; l += itoa_(buf + l, sl->dur); buf[l] = 0; hud_text(5, ty + 1, buf); }
        else if (sl->n > 1) { buf[0] = 'x'; itoa_(buf + 1, sl->n); hud_text(5, ty + 1, buf); }
      } else hud_dim(5, ty, "- vacio -");
      if (i < 9) { buf[0] = '['; buf[1] = (char)('1' + i); buf[2] = ']'; buf[3] = 0; hud_text(26, ty, buf); }
      if (i == msel2) hud_text(18, ty + 1, "<mover>");
    }
    chrome_foot();
    hud_text(1, 17, "A: coger / soltar y cambiar");
    hud_text(1, 18, "B: volver");
    break;
  case MN_CRAFT: {
    int n = cat_count(mcat);
    chrome(marg == 11 ? "SOPORTE DE POCIONES" : "FABRICAR");
    if (marg != 11) {
      hud_text(1, 2, "<"); hud_text(28, 2, ">");
      const char *cn = CAT_NAMES[mcat]; int cl = 0; while (cn[cl]) cl++;
      hud_text(15 - cl / 2, 2, cn);
    }
    if (n) mn_count(mcur, n);
    for (int r = 0; r < 6; r++) {
      int i = mtop + r, ty = 4 + r * 2;
      if (i >= n) break;
      const Recipe *rc = cat_recipe(mcat, i);
      int ok = can_craft(rc) || P.mode == MODE_CREATIVE;
      if (i == mcur) mn_bar(8, 232, ty, 16);
      mn_icon(16, ty * 8, rc->out);
      int k = 0; const char *nm = item_name(rc->out);
      while (nm[k] && k < 18) { buf[k] = nm[k]; k++; }
      if (rc->n > 1) { buf[k++] = ' '; buf[k++] = 'x'; k += itoa_(buf + k, rc->n); }
      buf[k] = 0;
      hud_txt2(5, ty, buf, !ok);
      recipe_brief(buf, rc);
      hud_dim(5, ty + 1, buf);
    }
    chrome_foot();
    if (n) draw_recipe_need(cat_recipe(mcat, mcur));
    hud_text(1, 19, marg == 11 ? "A: preparar   B: salir" : "A: fabricar  L/R: categoria  B: volver");
    break;
  }
  case MN_CHEST: {
    chrome("COFRE");
    hud_text(15, 0, "A:pasar L/R:lado");
    int ci = marg;
    if (mpane == 0) mn_bar(8, 120, 3 + mcur - mtop, 8); else mn_bar(128, 240, 3 + cur2 - top2, 8);
    for (int r = 0; r < 15; r++) {
      int i = mtop + r;
      if (i < 27 && ci >= 0) { fmt_slot(buf, &chest_inv[ci][i], 13); hud_text(2, 3 + r, buf); }
      int j = top2 + r;
      if (j < INV_N) { fmt_slot(buf, &inv[j], 12); hud_text(17, 3 + r, buf); }
    }
    hud_text(mpane == 0 ? 1 : 16, 3 + (mpane == 0 ? mcur - mtop : cur2 - top2), ">");
    break;
  }
  case MN_TRADE: {
    chrome(PROF_NAMES[marg % 5]);
    for (int i = 0; i < TRADE_N[marg % 5]; i++) {
      const Trade *t = &TRADES[marg % 5][i];
      int ty = 2 + i * 3, ok = inv_count(t->give) >= t->gn;
      if (i == mcur) mn_bar(8, 232, ty, 16);
      mn_icon(16, ty * 8, t->give);
      mn_icon(208, ty * 8, t->get);
      int k = 0; k += itoa_(buf + k, t->gn); buf[k++] = ' ';
      const char *nm = item_name(t->give); for (int q = 0; nm[q] && q < 14; q++) buf[k++] = nm[q];
      buf[k] = 0; hud_txt2(5, ty, buf, !ok);
      k = 0; buf[k++] = '>'; buf[k++] = ' '; k += itoa_(buf + k, t->tn); buf[k++] = ' ';
      nm = item_name(t->get); for (int q = 0; nm[q] && q < 14; q++) buf[k++] = nm[q];
      buf[k] = 0; hud_txt2(5, ty + 1, buf, !ok);
    }
    chrome_foot();
    hud_text(1, 17, "A: comerciar   B: salir");
    break;
  }
  case MN_ENCH: {
    chrome("MESA DE ENCANTAMIENTOS");
    Slot *s = &inv[P.sel];
    hud_text(1, 3, "Objeto en mano:");
    hud_text(1, 4, s->id ? item_name(s->id) : "(nada)");
    if (s->id) mn_icon(208, 3 * 8, s->id);
    int kd = s->id ? ITM[s->id].kind : 99;
    int okk = (kd == K_SWORD || kd == K_PICK || kd == K_ARMOR || kd == K_BOW) && !s->en;
    if (!okk) hud_dim(1, 6, s->en ? "Ya esta encantado" : "No se puede encantar");
    mn_bar(8, 232, 8 + mcur * 2, 8);
    for (int i = 0; i < 3; i++) {
      hud_text(3, 8 + i * 2, "Nivel");
      hud_num(9, 8 + i * 2, i + 1);
      hud_text(12, 8 + i * 2, "cuesta");
      hud_num(19, 8 + i * 2, i + 1);
      hud_text(21, 8 + i * 2, "niv+");
      hud_num(25, 8 + i * 2, i + 1);
      hud_text(26, 8 + i * 2, "lap");
    }
    hud_text(1, 8 + mcur * 2, ">");
    chrome_foot();
    hud_text(1, 17, "Tienes:");
    hud_num(9, 17, P.lvl); hud_text(12, 17, "niv"); hud_num(17, 17, inv_count(I_LAPIS)); hud_text(20, 17, "lapis");
    hud_text(1, 19, "A: encantar   B: salir");
    break;
  }
  case MN_ACH:
    chrome("LOGROS");
    for (int r = 0; r < 14; r++) {
      int i = mtop + r;
      if (i >= ACH_N) break;
      int got = (ach_mask & (1u << i)) != 0;
      hud_txt2(2, 3 + r, got ? "[x]" : "[ ]", !got);
      hud_txt2(6, 3 + r, ACH_NAMES[i], !got);
    }
    chrome_foot();
    hud_text(1, 17, "B: volver");
    break;
  case MN_CREATIVE:
    chrome("OBJETOS");
    mn_count(mcur, cre_n);
    for (int r = 0; r < 7; r++) {
      int i = mtop + r, ty = 2 + r * 2;
      if (i >= cre_n) break;
      if (i == mcur) mn_bar(8, 232, ty, 16);
      mn_icon(16, ty * 8, cre_list[i]);
      hud_text(5, ty, item_name(cre_list[i]));
      if (ITM[cre_list[i]].dur) hud_dim(5, ty + 1, "herramienta");
    }
    chrome_foot();
    hud_text(1, 17, "A: tomar pila   B: volver");
    break;
  case MN_HELP:
    chrome("AYUDA");
    hud_text(1, 3, "Cruz: girar y caminar");
    hud_text(1, 5, "A: minar, atacar, usar");
    hud_text(1, 7, "B: poner bloque / usar objeto");
    hud_text(1, 9, "L / R: cambiar casilla");
    hud_text(1, 11, "Start: menu   Select: mapa");
    hud_text(1, 13, "Entra a las puertas de las");
    hud_text(1, 14, "colinas para ir a las cuevas.");
    hud_text(1, 15, "Anillo 3x3 de obsidiana=Nether");
    chrome_foot();
    hud_text(1, 17, "B: volver");
    break;
  case MN_DEAD:
    hud_fill_panel(); mn_reset();
    hud_text(10, 8, "HAS MUERTO");
    hud_text(5, 11, P.mode == MODE_HARD ? "Hardcore: mundo perdido" : "A: reaparecer");
    break;
  case MN_WIN:
    hud_fill_panel(); mn_reset();
    hud_text(8, 6, "FELICIDADES!");
    hud_text(3, 9, "Has derrotado al Dragon");
    hud_text(3, 11, "del End. Puedes seguir");
    hud_text(3, 12, "jugando y construyendo.");
    hud_text(8, 15, "A: continuar");
    break;
  default: break;
  }
  mredraw = 0;
}

static void draw_map(void) {
  hud_fill_panel(); mn_reset();
  int sc = cur_dim == D_OVER ? 4 : 2;
  int ox = clampi(PTX() - 15 * sc, 0, MW - 30 * sc), oy = clampi(PTY() - 10 * sc, 0, MH - 20 * sc);
  if (ox < 0) ox = 0;
  if (oy < 0) oy = 0;
  static const u8 col[G_COUNT] = {2, 8, 7, 9, 11, 5, 6, 12, 7, 3, 10, 6, 1, 8, 9, 7, 7, 7, 3, 3, 11};
  for (int cy = 0; cy < 20; cy++)
    for (int cx = 0; cx < 30; cx++) {
      int tx = ox + cx * sc + sc / 2, ty = oy + cy * sc + sc / 2;
      if (tx >= MW || ty >= MH) { hud_tile(cx, cy, 110 + 2 - 1); continue; }
      int c = col[getg(tx, ty)];
      u8 o = geto(tx, ty);
      if (o == O_MTN || o == O_STONE || o == O_COBB || o == O_CAVEW || o == O_ENDST) c = 10;
      else if (o == O_TREE || o == O_PINE || o == O_JTREE) c = 8;
      else if (o == O_DOOR || o == O_EXIT || o == O_NPORTAL || o == O_EPORTAL || o == O_WELL || o == O_FRAME) c = 1;
      else if (o == O_PLANK || o == O_CHEST) c = 7;
      hud_tile(cx, cy, 110 + c - 1);
    }
  int px = (PTX() - ox) / sc, py = (PTY() - oy) / sc;
  if ((game_time >> 4) & 1) hud_tile(px, py, T_CHAR('@'));
  hud_text(1, 19, "B: volver");
}

/* alterna slots */
static void slot_swap(int a, int b) {
  if (a == b) return;
  Slot t = inv[a];
  if (inv[a].id && inv[a].id == inv[b].id && !inv[a].en && !inv[b].en && inv[a].dur == 0 && inv[b].dur == 0) {
    int tot = inv[a].n + inv[b].n;
    inv[b].n = (u8)(tot > 64 ? 64 : tot); inv[a].n = (u8)(tot - inv[b].n);
    if (!inv[a].n) { inv[a].id = 0; inv[a].en = 0; }
    return;
  }
  inv[a] = inv[b]; inv[b] = t;
}

static void apply_enchant(int lvl) {
  Slot *s = &inv[P.sel];
  if (!s->id || s->en) return;
  int kd = ITM[s->id].kind, t1, t2;
  if (kd == K_SWORD) { t1 = E_SHARP; t2 = E_KNOCK; }
  else if (kd == K_PICK) { t1 = E_EFF; t2 = E_FORT; }
  else if (kd == K_ARMOR) { t1 = E_PROT; t2 = E_UNB; }
  else if (kd == K_BOW) { t1 = E_POWER; t2 = E_UNB; }
  else return;
  if (P.mode != MODE_CREATIVE) {
    if (P.lvl < lvl || inv_count(I_LAPIS) < lvl) { say("Faltan niveles o lapis"); return; }
    P.lvl -= lvl; P.xp = 0; inv_take(I_LAPIS, lvl);
  }
  int t = rnd(2) ? t1 : t2;
  s->en = (u8)((t << 2) | lvl);
  say("Encantado!");
}

int ui_update(u16 pressed, u16 held) {
  if (menu_kind == MN_NONE) return 0;
  int up = pressed & KEY_UP, dn = pressed & KEY_DOWN;
  /* autorepeticion */
  if (held & (KEY_UP | KEY_DOWN)) { mrep++; if (mrep > 14 && (mrep & 3) == 0) { if (held & KEY_UP) up = 1; else dn = 1; } } else mrep = 0;
  int A = pressed & KEY_A, B = pressed & KEY_B;
  int lf = pressed & (KEY_LEFT | KEY_L), rt = pressed & (KEY_RIGHT | KEY_R);
  int old = mcur, oldc = mcat, oldp = mpane;
  switch (menu_kind) {
  case MN_PAUSE:
    if (up) mcur--; if (dn) mcur++;
    if (mcur < 0) mcur = PAUSE_N - 1; if (mcur >= PAUSE_N) mcur = 0;
    if (pressed & KEY_L) { P.sel = (u8)((P.sel + 8) % 9); }
    if (pressed & KEY_R) { P.sel = (u8)((P.sel + 1) % 9); }
    if (B || (pressed & KEY_START)) { close_menu(); return 1; }
    if (A) {
      switch (mcur) {
      case 0: close_menu(); return 1;
      case 1: ui_open(MN_INV, 0); return 1;
      case 2: ui_open(MN_CRAFT, 0); return 1;
      case 3: ui_open(MN_MAP, 0); return 1;
      case 4: ui_open(MN_ACH, 0); return 1;
      case 5: ui_open(MN_HELP, 0); return 1;
      case 6: save_game(0); say("Partida guardada (1)"); close_menu(); return 1;
      case 7: save_game(1); say("Partida guardada (2)"); close_menu(); return 1;
      case 8: if (P.mode == MODE_CREATIVE) ui_open(MN_CREATIVE, 0); else mredraw = 1; return 1;
      case 9: if (P.mode == MODE_CREATIVE) { close_menu(); player_set_fly(!P.fly); } else mredraw = 1; return 1;
      case 10: menu_kind = MN_NONE; return 2; /* volver al titulo */
      }
    }
    break;
  case MN_INV:
    if (up) mcur--; if (dn) mcur++;
    scroll_fix(&mcur, &mtop, INV_N, 7);
    if (A) { if (msel2 < 0) { msel2 = mcur; } else { slot_swap(msel2, mcur); msel2 = -1; } mredraw = 1; }
    if (B) { if (msel2 >= 0) { msel2 = -1; mredraw = 1; } else back_to_pause(); return 1; }
    break;
  case MN_CRAFT: {
    int n = cat_count(mcat);
    if (marg != 11) { if (lf) mcat = (mcat + 11) % 11; if (rt) mcat = (mcat + 1) % 11; }
    if (mcat != oldc) { mcur = 0; mtop = 0; mredraw = 1; }
    if (up) mcur--; if (dn) mcur++;
    if (n) scroll_fix(&mcur, &mtop, n, 6);
    if (A && n) { do_craft(cat_recipe(mcat, mcur)); mredraw = 1; }
    if (B) { if (marg == 11) close_menu(); else back_to_pause(); return 1; }
    break;
  }
  case MN_CHEST: {
    int ci = marg;
    if (lf || rt) { mpane ^= 1; }
    if (mpane == 0) { if (up) mcur--; if (dn) mcur++; scroll_fix(&mcur, &mtop, 27, 15); }
    else { if (up) cur2--; if (dn) cur2++; scroll_fix(&cur2, &top2, INV_N, 15); }
    if (A && ci >= 0) {
      if (mpane == 0) {
        Slot *c = &chest_inv[ci][mcur];
        if (c->id) { int id = c->id, n = c->n; int left = inv_add((u8)id, n); c->n = (u8)left; if (!left) { c->id = 0; c->en = 0; } }
      } else {
        Slot *s = &inv[cur2];
        if (s->id) {
          for (int k = 0; k < 27; k++) {
            Slot *c = &chest_inv[ci][k];
            if (c->id == s->id && !s->en && !c->en && c->n + s->n <= 64 && !s->dur) { c->n = (u8)(c->n + s->n); s->id = 0; s->n = 0; break; }
          }
          if (s->id) for (int k = 0; k < 27; k++) if (!chest_inv[ci][k].id) { chest_inv[ci][k] = *s; s->id = 0; s->n = 0; s->en = 0; break; }
        }
      }
      mredraw = 1;
    }
    if (B) { close_menu(); return 1; }
    if (mpane != oldp) mredraw = 1;
    break;
  }
  case MN_TRADE: {
    int n = TRADE_N[marg % 5];
    if (up) mcur--; if (dn) mcur++;
    if (mcur < 0) mcur = n - 1; if (mcur >= n) mcur = 0;
    if (A) {
      const Trade *t = &TRADES[marg % 5][mcur];
      if (inv_count(t->give) >= t->gn && inv_can_add(t->get, t->tn)) {
        inv_take(t->give, t->gn); inv_add(t->get, t->tn); stat_trades++; add_xp(1); say("Trato hecho");
      } else say("No puedes comerciar");
      mredraw = 1;
    }
    if (B) { close_menu(); return 1; }
    break;
  }
  case MN_ENCH:
    if (up) mcur--; if (dn) mcur++;
    if (mcur < 0) mcur = 2; if (mcur > 2) mcur = 0;
    if (A) { apply_enchant(mcur + 1); mredraw = 1; }
    if (B) { close_menu(); return 1; }
    break;
  case MN_ACH:
    if (up) mcur--; if (dn) mcur++;
    scroll_fix(&mcur, &mtop, ACH_N, 14);
    mtop = mcur < 14 ? 0 : mcur - 13;
    if (B) { back_to_pause(); return 1; }
    break;
  case MN_CREATIVE:
    if (up) mcur--; if (dn) mcur++;
    scroll_fix(&mcur, &mtop, cre_n, 7);
    if (A) { u8 id = cre_list[mcur]; int st = ITM[id].kind == K_MAT || ITM[id].kind == K_PLACE || ITM[id].kind == K_FOOD ? 64 : 1; inv_add(id, st); say(item_name(id)); }
    if (B) { back_to_pause(); return 1; }
    break;
  case MN_MAP:
    draw_map();
    if (B || (pressed & (KEY_SELECT | KEY_START))) { close_menu(); return 1; }
    return 1;
  case MN_HELP:
    if (B) { back_to_pause(); return 1; }
    break;
  case MN_DEAD:
    if (A) {
      if (P.mode == MODE_HARD) { save_erase(cur_slot); menu_kind = MN_NONE; return 2; }
      respawn(); close_menu(); return 1;
    }
    break;
  case MN_WIN:
    if (A || B) { close_menu(); return 1; }
    break;
  default: close_menu(); return 1;
  }
  if (mcur != old) mredraw = 1;
  if (mredraw) { hud_fill_panel(); draw_menu(); }
  return 1;
}

int render_scroll_x(void) { return scr_x; }
int render_scroll_y(void) { return scr_y; }
