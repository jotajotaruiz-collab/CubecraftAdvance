/* view3d.c - vista 3D en tercera persona (estilo "Mode 7")
 *
 * El suelo es la capa afin BG2 (modo 1) con una matriz distinta por cada linea de pantalla
 * (HDMA en cada HBlank): da perspectiva real por hardware. La niebla es una mezcla alfa por linea
 * contra el color del cielo (que tambien cambia por linea, como degradado).
 * Los objetos del mundo, mobs y jugador son sprites afines escalados segun su distancia
 * (8 niveles de escala), ordenados de cerca a lejos.
 * La camara va detras del jugador y gira de 90 en 90 grados con SELECT. */
#include "game.h"

int v3d_on = 1;
int v3d_yawq;  /* destino de la camara 0..3 (cada paso = 90 grados) */
static int yaw; /* angulo actual 0..255 (256 = vuelta completa) */
int v3d_dirty = 1;

#define F3 128   /* distancia focal */
#define DB3 128  /* distancia de la camara al jugador (px) */
#define HZ3 (-24)
#define KZ3 (DB3 * (120 - HZ3))
#define ZFAR 256
#define Y0 (HZ3 + KZ3 / ZFAR)

static const s16 SIN256[256] = {
#include "sin256.h"
};
static int isin(int a) { return SIN256[a & 255]; }
static int icos(int a) { return SIN256[(a + 64) & 255]; }

EWRAM u32 v3d_tab[160][4];   /* PA|PB, PC|PD, X, Y por linea */
EWRAM u16 v3d_bld[160];  /* BLDALPHA por linea */
EWRAM u16 v3d_sky[160];  /* color de fondo (cielo) por linea */
EWRAM static u16 floor_map[2048]; /* mapa afin 64x64 (bytes) = 32x32 metatiles */
static u16 zt[160];
static u16 rcp[300];
static u8 zgrp[300];
static int floor_cx = -99999, floor_cy = -99999;
static int hw_on;
int v3d_hw_on(void) { return hw_on; }

#define ABS(v) ((v) < 0 ? -(v) : (v))
static const s16 SQ[8] = {512, 384, 307, 256, 218, 184, 159, 141}; /* escalas (8.8) */

static void v3d_tables_init(void) {
  static int done;
  if (done) return;
  done = 1;
  for (int y = 0; y < 160; y++) zt[y] = (y > HZ3) ? (u16)(KZ3 / (y - HZ3)) : 0;
  for (int z = 1; z < 300; z++) rcp[z] = (u16)(65536 / z);
  rcp[0] = 65535;
  for (int z = 0; z < 300; z++) {
    int best = 0, bd = 99999;
    for (int k = 0; k < 8; k++) {
      int zk = F3 * 256 / SQ[k], d = ABS(z - zk);
      if (d < bd) { bd = d; best = k; }
    }
    zgrp[z] = (u8)best;
  }
}

/* ---------------------------------------------------------------- cielo */
static u16 rgb5(int r, int g, int b) {
  if (r > 31) r = 31; if (g > 31) g = 31; if (b > 31) b = 31;
  if (r < 0) r = 0; if (g < 0) g = 0; if (b < 0) b = 0;
  return (u16)(r | (g << 5) | (b << 10));
}
static void sky_build(void) {
  int tr, tg, tb;
  gfx_get_tint(&tr, &tg, &tb);
  int hr, hg, hb, ur, ug, ub; /* horizonte / cenit */
  if (cur_dim == D_OVER) { hr = 22; hg = 28; hb = 31; ur = 10; ug = 19; ub = 31; }
  else if (cur_dim == D_NETH) { hr = 14; hg = 3; hb = 2; ur = 6; ug = 1; ub = 1; }
  else if (cur_dim == D_END) { hr = 8; hg = 5; hb = 12; ur = 3; ug = 2; ub = 6; }
  else { hr = 4; hg = 4; hb = 5; ur = 1; ug = 1; ub = 2; }
  int amb = cur_dim == D_OVER ? dark_level_ambient() : 0;
  int dim = 32 - amb * 7; if (dim < 6) dim = 6;
  hr = hr * tr * dim >> 10; hg = hg * tg * dim >> 10; hb = hb * tb * dim >> 10;
  ur = ur * tr * dim >> 10; ug = ug * tg * dim >> 10; ub = ub * tb * dim >> 10;
  for (int y = 0; y < 160; y++) {
    int f = y >= Y0 ? 32 : y * 32 / Y0; /* 0 arriba .. 32 horizonte */
    v3d_sky[y] = rgb5(ur + (hr - ur) * f / 32, ug + (hg - ug) * f / 32, ub + (hb - ub) * f / 32);
  }
}

/* ------------------------------------------------------ camara y tablas */
static int cam_qx, cam_qy; /* camara en 1/256 px */
static int fwx, fwy, rtx, rty; /* adelante / derecha (8.8) */

void v3d_turn(int d) { v3d_yawq = (v3d_yawq + d) & 3; }
int v3d_yaw_view(void) { return ((yaw + 32) >> 6) & 3; } /* cuarto de giro mas cercano */

static void camera_update(void) {
  int tgt = v3d_yawq * 64, d = (tgt - yaw) & 255;
  if (d) {
    if (d > 128) { yaw -= 8; if (((tgt - yaw) & 255) > 128 || ((tgt - yaw) & 255) == 0) yaw = tgt; }
    else { yaw += 8; if (((tgt - yaw) & 255) > 128 || ((tgt - yaw) & 255) == 0) yaw = tgt; }
    yaw &= 255;
  }
  rtx = icos(yaw); rty = isin(yaw);
  fwx = isin(yaw); fwy = -icos(yaw);
  cam_qx = P.x * 16 - fwx * DB3;
  cam_qy = P.y * 16 - fwy * DB3;
}

static void tables_build(void) {
  for (int y = 0; y < 160; y++) {
    u32 pa = 0, pc = 0, x = 0, yy = 0;
    int eva = 0;
    if (y >= Y0) {
      int z = zt[y], s = z * 2; /* s = z/F3 en 8.8 */
      int PA = (rtx * s) >> 8, PC = (rty * s) >> 8;
      pa = (u16)PA; pc = (u16)PC;
      x = (u32)(cam_qx + fwx * z - PA * 120);
      yy = (u32)(cam_qy + fwy * z - PC * 120);
      eva = z <= 140 ? 16 : 16 * (ZFAR - z) / (ZFAR - 140);
      if (eva < 0) eva = 0;
    }
    v3d_tab[y][0] = pa; v3d_tab[y][1] = pc; v3d_tab[y][2] = x; v3d_tab[y][3] = yy;
    v3d_bld[y] = (u16)(eva | ((16 - eva) << 8));
  }
}

/* ------------------------------------------------------------- suelo */
static void floor_update(void) {
  int ax = (cam_qx >> 8) + (fwx * 160 >> 8), ay = (cam_qy >> 8) + (fwy * 160 >> 8);
  int cx = ax >> 4, cy = ay >> 4;
  if (!v3d_dirty && cx == floor_cx && cy == floor_cy) return;
  v3d_dirty = 0; floor_cx = cx; floor_cy = cy;
  for (int my = 0; my < 32; my++) {
    int ty = cy - 16 + my;
    int row = (ty & 31) * 64;
    for (int mx = 0; mx < 32; mx++) {
      int tx = cx - 16 + mx, t = 0;
      if (tx >= 0 && ty >= 0 && tx < MW && ty < MH) {
        u8 g = wg[tidx(tx, ty)];
        t = (g == G_VOID) ? 0 : gfx_ground_slot(g) * 4;
      }
      int i = row + (tx & 31);
      floor_map[i] = (u16)(t | ((t + 1) << 8));
      floor_map[i + 32] = (u16)((t + 2) | ((t + 3) << 8));
    }
  }
}

/* -------------------------------------------------------------- sprites */
typedef struct { s16 z, sx, sy; u16 tile; u8 size, w, h, off, pri; } Bb; /* sy = punto de suelo, off = px bajo el suelo */
#define MAXBB 56
static Bb bb[MAXBB + 8];
static int nbb;

static int project(int wxp, int wyp, int zbias, int *sx, int *sy, int *z) {
  int rx = wxp - (cam_qx >> 8), ry = wyp - (cam_qy >> 8);
  int zz = ((rx * fwx + ry * fwy) >> 8) + zbias;
  if (zz < 50 || zz > 232) return 0;
  int l = (rx * rtx + ry * rty) >> 8;
  *sx = 120 + ((l * F3 * rcp[zz]) >> 16);
  *sy = HZ3 + ((KZ3 * rcp[zz]) >> 16);
  *z = zz;
  return 1;
}
static void add_bb(int z, int sx, int sy, int tile, int size, int w, int h, int off, int pri) {
  if (nbb >= MAXBB) {
    /* lleno: sustituye al mas lejano si este esta mas cerca */
    int fi = 0; for (int i = 1; i < nbb; i++) if (bb[i].z > bb[fi].z) fi = i;
    if (bb[fi].z <= z) return;
    nbb--; bb[fi] = bb[nbb];
  }
  Bb *b = &bb[nbb++];
  b->z = (s16)z; b->sx = (s16)sx; b->sy = (s16)sy; b->tile = (u16)tile; b->size = (u8)size; b->w = (u8)w; b->h = (u8)h; b->off = (u8)off; b->pri = (u8)pri;
}
/* anade un sprite de un slot OBJ (16x16 = 1 slot; 16x32 = 2) */
static void add_slot(int wxp, int wyp, int zbias, int slot, int size, int w, int h, int off, int lift, int pri) {
  int sx, sy, z;
  if (!project(wxp, wyp, zbias, &sx, &sy, &z)) return;
  add_bb(z, sx, sy - lift * SQ[zgrp[z]] / 256, slot * 8, size, w, h, off, pri);
}

static int aff_put(int n, const Bb *b) {
  int g = zgrp[b->z], s = SQ[g];
  int cx = b->sx, cy = b->sy + (b->off * s >> 8) - (b->h * s >> 9);
  int bw = b->w * 2 * s >> 8, bh = b->h * 2 * s >> 8; /* caja visible aproximada para el recorte */
  if (cx + bw / 2 < 0 || cx - bw / 2 >= 240 || cy + bh / 2 < 0 || cy - bh / 2 >= 160) return n;
  if (n >= 128) return n;
  int x = cx - b->w, y = cy - b->h; /* esquina de la caja doble = centro - (w, h) */
  int shape = 0, size = b->size;
  switch (size) {
  case 3: shape = 0x8000; size = 2; break;
  case 4: shape = 0x4000; size = 1; break;
  case 5: shape = 0x4000; size = 2; break;
  case 6: shape = 0x4000; size = 0; break;
  default: break;
  }
  oam_sh[n * 4] = (u16)((y & 255) | 0x100 | 0x200 | 0x2000 | shape);
  oam_sh[n * 4 + 1] = (u16)((x & 511) | (g << 9) | (size << 14));
  oam_sh[n * 4 + 2] = (u16)(b->tile | (b->pri << 10));
  return n + 1;
}

static void set_groups(void) {
  for (int g = 0; g < 8; g++) {
    int inv = 65536 / SQ[g]; /* paso de textura por pixel (8.8) */
    oam_sh[g * 16 + 3] = (u16)inv;
    oam_sh[g * 16 + 7] = 0;
    oam_sh[g * 16 + 11] = 0;
    oam_sh[g * 16 + 15] = (u16)inv;
  }
}

int v3d_sprites(int n) {
  nbb = 0;
  int qv = v3d_yaw_view(); /* cuarto de giro para orientar sprites */
  int ctx = (cam_qx >> 8) + (fwx * 160 >> 8), cty = (cam_qy >> 8) + (fwy * 160 >> 8);
  ctx >>= 4; cty >>= 4;
  /* objetos del mundo */
  for (int ty = cty - 15; ty <= cty + 15; ty++) {
    if (ty < 0 || ty >= MH) continue;
    for (int tx = ctx - 15; tx <= ctx + 15; tx++) {
      if (tx < 0 || tx >= MW) continue;
      int i = tidx(tx, ty);
      u8 o = wo[i];
      if (!o) continue;
      u8 h2, v2;
      int os = gfx_obj_slot(o, (u8)(wst[i] >> 7), (u8)(wst[i] & 3), &h2, &v2);
      if (!os) continue;
      int sx, sy, z;
      if (!project(tx * 16 + 8, ty * 16 + 8, -8, &sx, &sy, &z)) continue;
      int g = zgrp[z], s = SQ[g];
      if (sx < -24 * 256 / s || sx > 240 + 24 * 256 / s) continue;
      if (sy - (16 * s >> 8) > 160) continue;
      add_bb(z, sx, sy, gfx_meta_obj(os) * 8, 1, 16, 16, 0, 2);
    }
  }
  /* mobs */
  for (int i = 0; i < MAXENT; i++) {
    Ent *e = &ents[i];
    if (!(e->flags & EF_ALIVE)) continue;
    if (e->hurt > 0 && (e->hurt & 2)) continue;
    if (e->flags & EF_FUSE) { if (e->t2 & 4) continue; }
    int f = ((e->anim >> 3) & 1);
    int wx = e->x >> 4, wy = e->y >> 4;
    { int px_, py_, pz_; if (!project(wx, wy, 0, &px_, &py_, &pz_) || px_ < -40 || px_ > 280) continue; } /* fuera de vista: no pedir sprite */
    int sd = (e->dir - qv) & 3;
    if (e->type == M_GHAST) add_slot(wx, wy, 0, S_GHAST, 2, 32, 32, 0, 24, 2);
    else if (e->type == M_DRAGON) add_slot(wx, wy, 0, S_DRAGON + f * 4, 2, 32, 32, 0, 22, 2);
    else {
      u8 hf, tall;
      int walking = MOBS[e->type].fly ? (e->st != 0) : e->stp;
      int sl = gfx_mob_slot(e->type, sd, walking ? f : 0, &hf, &tall);
      int lift = MOBS[e->type].fly ? 10 : 0;
      if (tall) add_slot(wx, wy, 0, sl, 3, 16, 32, 6, lift, 2);
      else add_slot(wx, wy, 0, sl, 1, 16, 16, 6, lift, 2);
    }
  }
  /* jugador */
  if (!(P.hurt > 0 && (P.hurt & 4)) && !P.sleeping) {
    int bob = (P.moving && ((P.anim >> 3) & 1)) ? 1 : 0;
    int lunge = P.swing > 5 ? 2 : P.swing > 2 ? 1 : 0;
    int rise = P.fly ? 5 + ((game_time >> 4) & 1) : 0;
    int sd = (P.dir - qv) & 3;
    int px = PX() + DX[P.dir] * lunge, py = PY() + DY[P.dir] * lunge;
    if (P.fly) add_slot(PX(), PY(), 1, S_SHADOW, 1, 16, 16, 2, 0, 2);
    if (P.boat) add_slot(PX(), PY(), 1, S_BOAT, 1, 16, 16, 4, 0, 2);
    add_slot(px, py, 0, S_PLAYER + (sd * 2 + bob) * 2, 3, 16, 32, 6, rise, 2);
  } else if (P.sleeping) add_slot(PX(), PY(), 0, S_PLAYER + 8, 3, 16, 32, 6, 0, 2);
  /* tajo de la espada, cursor y efectos (en el suelo, delante del jugador) */
  if (P.swing > 0) {
    int k = (8 - P.swing) >> 1; if (k < 0) k = 0; if (k > 3) k = 3;
    int d = (P.dir - qv) & 3; /* direccion relativa a la camara */
    int ox = DX[P.dir] * 14, oy = DY[P.dir] * 14;
    /* el tajo horizontal/vertical se elige segun el eje en pantalla */
    int horiz = (d == 1 || d == 3);
    add_slot(PX() + ox, PY() + oy, -1, (horiz ? S_SLASH : S_SLASHV) + k, 1, 16, 16, 4, 6, 1);
  }
  for (int i = 0; i < 12; i++)
    if (fxs[i].t > 0) {
      if (fxs[i].kind == 1) add_slot(fxs[i].x >> 4, fxs[i].y >> 4, -1, S_PART + (fxs[i].t > 12 ? 0 : fxs[i].t > 6 ? 1 : 2), 1, 16, 16, 8, 0, 1);
      else add_slot(fxs[i].x >> 4, fxs[i].y >> 4, -1, S_HIT + (9 - fxs[i].t) / 3, 1, 16, 16, 8, 10, 1);
    }
  for (int i = 0; i < MAXPROJ; i++) {
    Proj *p = &projs[i];
    if (!p->type) continue;
    int d = (p->dir - qv) & 3;
    if (p->type == 2) add_slot(p->x >> 4, p->y >> 4, 0, S_FIRE, 1, 16, 16, 8, 8, 2);
    else add_slot(p->x >> 4, p->y >> 4, 0, (d & 1) ? S_ARROWH : S_ARROW, 1, 16, 16, 8, 8, 2);
  }
  for (int i = 0; i < 6; i++)
    if (booms[i].t > 0) {
      int t = booms[i].t, bx = booms[i].x >> 4, by = booms[i].y >> 4;
      add_slot(bx, by, -1, S_FIRE, 1, 16, 16, 8, 8, 1);
      add_slot(bx + t, by, -1, S_FIRE, 1, 16, 16, 8, 8, 1);
      add_slot(bx - t, by, -1, S_FIRE, 1, 16, 16, 8, 8, 1);
      add_slot(bx, by + t, -1, S_FIRE, 1, 16, 16, 8, 8, 1);
      add_slot(bx, by - t, -1, S_FIRE, 1, 16, 16, 8, 8, 1);
    }
  /* ordenar de cerca a lejos (los primeros indices OAM se dibujan encima) */
  for (int i = 1; i < nbb; i++) {
    Bb t = bb[i]; int j = i - 1;
    while (j >= 0 && bb[j].z > t.z) { bb[j + 1] = bb[j]; j--; }
    bb[j + 1] = t;
  }
  n = 32;
  for (int i = 0; i < nbb; i++) n = aff_put(n, &bb[i]);
  return n;
}

void v3d_set(int on) { v3d_on = on; v3d_dirty = 1; }

/* ------------------------------------------------------ marco a marco */
void v3d_frame(void) {
  v3d_tables_init();
  camera_update();
  tables_build();
  sky_build();
  floor_update();
  set_groups();
}

#ifndef HOST
#define DMA0SAD (*(volatile u32 *)0x040000B0)
#define DMA0DAD (*(volatile u32 *)0x040000B4)
#define DMA0CNT (*(volatile u32 *)0x040000B8)
#define DMA1SAD (*(volatile u32 *)0x040000BC)
#define DMA1DAD (*(volatile u32 *)0x040000C0)
#define DMA1CNT (*(volatile u32 *)0x040000C4)
#define DMA2SAD (*(volatile u32 *)0x040000C8)
#define DMA2DAD (*(volatile u32 *)0x040000CC)
#define DMA2CNT (*(volatile u32 *)0x040000D0)
#define REG32(a) (*(volatile u32 *)(a))
static void copy_floor(void) {
  volatile u32 *d = (volatile u32 *)(VRAM16 + (30 * 0x800) / 2);
  const u32 *s = (const u32 *)floor_map;
  for (int i = 0; i < 1024; i++) d[i] = s[i];
}
#endif

/* se llama justo despues del vsync (en el VBlank): sube el mapa del suelo y arma el HDMA */
void v3d_vblank(int show) {
#ifdef HOST
  hw_on = show;
  extern void host_v3d_floor(const u16 *m);
  host_v3d_floor(floor_map);
#else
  DMA0CNT = 0; DMA1CNT = 0; DMA2CNT = 0;
  if (!show) { hw_on = 0; return; }
  hw_on = 1;
  copy_floor();
  REG32(0x04000020) = v3d_tab[0][0]; REG32(0x04000024) = v3d_tab[0][1];
  REG32(0x04000028) = v3d_tab[0][2]; REG32(0x0400002C) = v3d_tab[0][3];
  REG_BLDALPHA = v3d_bld[0];
  PAL[0] = v3d_sky[0];
  DMA0SAD = (u32)&v3d_tab[1][0]; DMA0DAD = 0x04000020; DMA0CNT = 0xA6600000u | 4;
  DMA1SAD = (u32)&v3d_bld[1]; DMA1DAD = 0x04000052; DMA1CNT = 0xA2400000u | 1;
  DMA2SAD = (u32)&v3d_sky[1]; DMA2DAD = 0x05000000; DMA2CNT = 0xA2400000u | 1;
#endif
}
