/* entity.c - mobs, proyectiles, TNT, cultivos, aparicion de enemigos y reloj del mundo */
#include "game.h"

Ent ents[MAXENT];
Proj projs[MAXPROJ];
Boom booms[6];
Fx fxs[12];
void fx_spawn(int x, int y) { for (int i = 0; i < 12; i++) if (fxs[i].t <= 0) { fxs[i].x = x; fxs[i].y = y; fxs[i].t = 9; fxs[i].kind = 0; return; } }
void fx_puff(int x, int y, int n) {
  for (int k = 0; k < n; k++)
    for (int i = 0; i < 12; i++) if (fxs[i].t <= 0) { fxs[i].x = (x + rnd(13) - 6) << 4; fxs[i].y = (y + rnd(17) - 12) << 4; fxs[i].t = 12 + rnd(6); fxs[i].kind = 1; break; }
}
Ent *boss;
u32 game_time, day_t;
int diff_hard;

typedef struct { u8 x, y, t; } TntT;
static TntT tnts[8];

static const s8 CIR[16] = {64, 59, 45, 24, 0, -24, -45, -59, -64, -59, -45, -24, 0, 24, 45, 59};

void ents_clear(void) {
  for (int i = 0; i < MAXENT; i++) ents[i].flags = 0;
  for (int i = 0; i < MAXPROJ; i++) projs[i].type = 0;
  for (int i = 0; i < 8; i++) tnts[i].t = 0;
  for (int i = 0; i < 12; i++) fxs[i].t = 0;
  boss = 0;
}

Ent *ent_spawn(int type, int tx, int ty) {
  for (int i = 0; i < MAXENT; i++)
    if (!(ents[i].flags & EF_ALIVE)) {
      Ent *e = &ents[i];
      e->x = tx * 256 + 128; e->y = ty * 256 + 128;
      e->type = (u8)type; e->hp = MOBS[type].hp; e->flags = EF_ALIVE; e->t = (s16)rnd(60); e->t2 = 0;
      e->dir = (u8)rnd(4); e->anim = 0; e->aux = 0; e->hurt = 0; e->st = 0; e->stp = 0; e->spd = 0;
      return e;
    }
  return 0;
}

static int ent_free(Ent *e, int x, int y) {
  const MobInfo *m = &MOBS[e->type];
  int h = (m->w == 2 ? 12 : 5) << 4;
  int x0 = (x - h) >> 8, x1 = (x + h - 1) >> 8, y0 = (y - h) >> 8, y1 = (y + h - 1) >> 8;
  if (e->type == M_SQUID) return is_water(x >> 8, y >> 8);
  for (int ty = y0; ty <= y1; ty++)
    for (int tx = x0; tx <= x1; tx++) {
      if (!tinb(tx, ty)) return 0;
      if (m->fly) { if (e->type == M_DRAGON) continue; int o = geto(tx, ty); if (o && !(BLK[o].flags & BF_WALK)) return 0; continue; }
      if (!tile_walk(tx, ty) || getg(tx, ty) == G_LAVA) return 0;
    }
  return 1;
}
/* ---- movimiento en cuadricula (mobs terrestres): paso a paso de casilla a casilla ---- */
static int ent_grid(const Ent *e) { return !MOBS[e->type].fly; }
static int ent_tile_ok(const Ent *e, int tx, int ty) {
  if (!tinb(tx, ty)) return 0;
  if (e->type == M_SQUID) return is_water(tx, ty);
  return tile_walk(tx, ty) && getg(tx, ty) != G_LAVA;
}
/* otra criatura (o el jugador) ocupa o va a ocupar la casilla */
int ent_tile_taken(int tx, int ty, const Ent *ignore) {
  if (ignore && PTX() == tx && PTY() == ty) return 1;
  if (ignore && P.stepping && (P.gx >> 8) == tx && (P.gy >> 8) == ty) return 1;
  for (int i = 0; i < MAXENT; i++) {
    const Ent *o = &ents[i];
    if (o == ignore || !(o->flags & EF_ALIVE) || MOBS[o->type].fly) continue;
    if ((o->x >> 8) == tx && (o->y >> 8) == ty) return 1;
    if (o->stp && (o->gx >> 8) == tx && (o->gy >> 8) == ty) return 1;
  }
  return 0;
}
static int ent_move(Ent *e, int dx, int dy) {
  int ok = 0;
  if (ent_grid(e)) {
    if (e->stp) return 1;
    int adx = dx < 0 ? -dx : dx, ady = dy < 0 ? -dy : dy;
    if (!adx && !ady) return 0;
    int d = adx >= ady ? (dx > 0 ? 3 : 1) : (dy > 0 ? 0 : 2);
    int tx = (e->x >> 8) + DX[d], ty = (e->y >> 8) + DY[d];
    if (!ent_tile_ok(e, tx, ty) || ent_tile_taken(tx, ty, e)) return 0;
    e->dir = (u8)d; e->gx = tx * 256 + 128; e->gy = ty * 256 + 128; e->stp = 1;
    int sp = adx > ady ? adx : ady;
    e->spd = (u8)(sp < 6 ? 6 : sp > 96 ? 96 : sp);
    return 1;
  }
  if (dx && ent_free(e, e->x + dx, e->y)) { e->x += dx; ok = 1; }
  if (dy && ent_free(e, e->x, e->y + dy)) { e->y += dy; ok = 1; }
  return ok;
}
static int sgn(int v) { return v > 0 ? 1 : v < 0 ? -1 : 0; }
static int iabs(int v) { return v < 0 ? -v : v; }
static void chase(Ent *e, int tx, int ty, int sp) {
  int dx = tx - (e->x >> 4), dy = ty - (e->y >> 4);
  if (ent_grid(e) && ((iabs(dx) <= 17 && iabs(dy) < 6) || (iabs(dy) <= 17 && iabs(dx) < 6))) { /* ya esta a su lado */
    e->dir = (u8)(iabs(dx) > iabs(dy) ? (dx > 0 ? 3 : 1) : (dy > 0 ? 0 : 2));
    return;
  }
  int sx = sgn(dx) * sp, sy = sgn(dy) * sp;
  if (iabs(dx) < 3) sx = 0;
  if (iabs(dy) < 3) sy = 0;
  if (iabs(dx) > iabs(dy)) { if (!ent_move(e, sx, 0)) { if (!ent_move(e, 0, sy ? sy : (e->anim & 32 ? sp : -sp))) ent_move(e, 0, 0); } else ent_move(e, 0, sy / 2); }
  else { if (!ent_move(e, 0, sy)) { if (!ent_move(e, sx ? sx : (e->anim & 32 ? sp : -sp), 0)) ent_move(e, 0, 0); } else ent_move(e, sx / 2, 0); }
  e->dir = (u8)(iabs(dx) > iabs(dy) ? (dx > 0 ? 3 : 1) : (dy > 0 ? 0 : 2));
}
static void flee(Ent *e, int sp) {
  int dx = (e->x >> 4) - PX(), dy = (e->y >> 4) - PY();
  if (iabs(dx) > iabs(dy)) { if (!ent_move(e, sgn(dx) * sp, 0)) ent_move(e, 0, (e->anim & 32 ? sp : -sp)); }
  else if (!ent_move(e, 0, sgn(dy) * sp)) ent_move(e, (e->anim & 32 ? sp : -sp), 0);
}
static void shoot(Ent *e, int type, int speed, int dmg) {
  int dx = PX() - (e->x >> 4), dy = PY() - (e->y >> 4);
  int m = iabs(dx) > iabs(dy) ? iabs(dx) : iabs(dy);
  if (m < 1) m = 1;
  proj_spawn(type, e->x, e->y, dx * speed / m, dy * speed / m, dmg, 1);
}

/* ------------------------------------------------------------------ danio */
static void ent_die(Ent *e) {
  e->flags = 0;
  const MobInfo *m = &MOBS[e->type];
  if (m->xp) add_xp(m->xp);
  if (m->ai != AI_ANIMAL && m->ai != AI_VILL && m->ai != AI_CAT && m->ai != AI_SQUID) stat_kills++;
  switch (e->type) {
  case M_COW: inv_add(I_RAW, 1 + rnd(2)); if (rnd(2)) inv_add(I_LEATHER, 1); break;
  case M_PIG: inv_add(I_RAW, 1 + rnd(2)); break;
  case M_SHEEP: inv_add(I_WOOL, 1 + rnd(2)); inv_add(I_RAW, 1); break;
  case M_CHICKEN: inv_add(I_RAW, 1); inv_add(I_FEATHER, rnd(3)); break;
  case M_ZOMBIE: if (rnd(100) < 25) inv_add(I_SLIME, 1); if (rnd(100) < 25) inv_add(I_RAW, 1); break;
  case M_SKELETON: inv_add(I_BONE, rnd(3)); inv_add(I_ARROW, rnd(3)); break;
  case M_CREEPER: inv_add(I_GUNPOWDER, 1 + rnd(2)); break;
  case M_ENDERMAN: if (rnd(100) < 55) inv_add(I_PEARL, 1); break;
  case M_BLAZE: if (rnd(100) < 60) inv_add(I_ROD, 1); break;
  case M_GHAST: inv_add(I_GUNPOWDER, 1 + rnd(2)); break;
  case M_PIGLIN: if (rnd(100) < 40) inv_add(I_GOLD, 1); break;
  case M_SQUID: break;
  case M_DRAGON:
    P.won = 1; boss = 0;
    for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) seto(24 + dx, 24 + dy, O_XPORTAL);
    inv_add(I_NSTAR, 1);
    say("El Dragon ha caido!"); msg_t = 300;
    break;
  default: break;
  }
  if (m->ai == AI_VILL) say("Un aldeano murio...");
}
static void ender_tp(Ent *e, int cx, int cy, int r);
void ent_damage(Ent *e, int dmg, int kx, int ky) {
  if (!(e->flags & EF_ALIVE)) return;
  e->hp = (u8)(e->hp > dmg ? e->hp - dmg : 0);
  e->hurt = 10;
  fx_spawn(e->x, e->y);
  const MobInfo *m = &MOBS[e->type];
  if (m->w == 1) { ent_move(e, kx * 16, 0); ent_move(e, 0, ky * 16); }
  if (m->ai == AI_ENDER || m->ai == AI_PIGLIN) e->flags |= EF_ANGRY;
  if (m->ai == AI_ENDER && e->hp > 0 && rnd(100) < 45) ender_tp(e, e->x >> 8, e->y >> 8, 4);
  if (m->ai == AI_ANIMAL || m->ai == AI_VILL) e->aux = 90;
  if (m->ai == AI_ANIMAL || m->ai == AI_VILL) e->st = 3;
  if (e->hp == 0) ent_die(e);
}
Ent *ent_at(int px, int py, int reach) {
  Ent *best = 0; int bd = 99999;
  for (int i = 0; i < MAXENT; i++) {
    Ent *e = &ents[i];
    if (!(e->flags & EF_ALIVE)) continue;
    int dx = iabs((e->x >> 4) - px), dy = iabs((e->y >> 4) - py);
    int r = reach + (MOBS[e->type].w == 2 ? 10 : 0);
    if (dx <= r && dy <= r && dx + dy < bd) { bd = dx + dy; best = e; }
  }
  return best;
}

/* -------------------------------------------------------------- proyectiles */
void proj_spawn(int type, int x, int y, int vx, int vy, int dmg, int owner) {
  for (int i = 0; i < MAXPROJ; i++)
    if (!projs[i].type) {
      Proj *p = &projs[i];
      p->type = (u8)type; p->x = x; p->y = y; p->vx = (s16)vx; p->vy = (s16)vy; p->life = 90; p->dmg = (u8)dmg; p->owner = (u8)owner;
      p->dir = (u8)(iabs(vx) > iabs(vy) ? (vx > 0 ? 3 : 1) : (vy > 0 ? 0 : 2));
      return;
    }
}
void projs_update(void) {
  for (int i = 0; i < MAXPROJ; i++) {
    Proj *p = &projs[i];
    if (!p->type) continue;
    p->x += p->vx; p->y += p->vy;
    if (--p->life == 0) { p->type = 0; continue; }
    int tx = p->x >> 8, ty = p->y >> 8;
    if (!tinb(tx, ty)) { p->type = 0; continue; }
    int o = geto(tx, ty);
    if (o && !(BLK[o].flags & BF_WALK)) {
      if (o == O_TNT && p->type == 2) { tnt_light(tx, ty); seto(tx, ty, 0); }
      p->type = 0; continue;
    }
    if (p->owner == 0) {
      Ent *e = ent_at(p->x >> 4, p->y >> 4, 9);
      if (e) { ent_damage(e, p->dmg, sgn(p->vx) * 3, sgn(p->vy) * 3); p->type = 0; }
    } else {
      int dx = (p->x >> 4) - PX(), dy = (p->y >> 4) - PY();
      if (iabs(dx) < 8 && iabs(dy) < 8) {
        if (P.block_t > 0 && p->type == 1) { p->owner = 0; p->vx = (s16)-p->vx; p->vy = (s16)-p->vy; }
        else { player_hurt(p->dmg, p->x >> 4, p->y >> 4); if (p->type == 2 && P.t_fire == 0) P.t_fire = 0; p->type = 0; }
      }
    }
  }
}

/* --------------------------------------------------------------------- TNT */
void tnt_light(int x, int y) {
  for (int i = 0; i < 8; i++) if (!tnts[i].t) { tnts[i].x = (u8)x; tnts[i].y = (u8)y; tnts[i].t = 54; return; }
}
void explode(int tx, int ty, int r, int dmg) {
  for (int dy = -r; dy <= r; dy++)
    for (int dx = -r; dx <= r; dx++) {
      if (dx * dx + dy * dy > r * r + 1) continue;
      int x = tx + dx, y = ty + dy, o = geto(x, y);
      if (!o || (BLK[o].flags & BF_UNB)) continue;
      if (o == O_TNT) { tnt_light(x, y); }
      seto(x, y, 0);
    }
  for (int i = 0; i < 6; i++) if (booms[i].t <= 0) { booms[i].x = tx * 256 + 128; booms[i].y = ty * 256 + 128; booms[i].t = 14; break; }
  int rpx = (r + 1) * 16;
  for (int i = 0; i < MAXENT; i++) {
    Ent *e = &ents[i];
    if (!(e->flags & EF_ALIVE)) continue;
    int dx = (e->x >> 4) - (tx * 16 + 8), dy = (e->y >> 4) - (ty * 16 + 8);
    if (iabs(dx) < rpx && iabs(dy) < rpx) ent_damage(e, dmg, sgn(dx) * 6, sgn(dy) * 6);
  }
  int dx = PX() - (tx * 16 + 8), dy = PY() - (ty * 16 + 8);
  if (iabs(dx) < rpx && iabs(dy) < rpx) { int pd = dmg; if (iabs(dx) + iabs(dy) > 24) pd = dmg / 2; player_hurt(pd, tx * 16 + 8, ty * 16 + 8); }
}
void tnt_update(void) {
  for (int i = 0; i < 8; i++)
    if (tnts[i].t && --tnts[i].t == 0) {
      int x = tnts[i].x, y = tnts[i].y;
      seto(x, y, 0);
      explode(x, y, 3, 14);
    }
  for (int i = 0; i < 6; i++) if (booms[i].t > 0) booms[i].t--;
}

/* ---------------------------------------------------------------------- IA */
static int hostile_ai(int ai) { return ai == AI_ZOMBIE || ai == AI_CREEPER || ai == AI_SKEL || ai == AI_BLAZE || ai == AI_GHAST || ai == AI_PIGLIN || ai == AI_ENDER; }

static void wander(Ent *e, int sp, int tmin, int tmax) {
  if (e->t > 0) e->t--;
  if (e->t <= 0) {
    if (rnd(100) < 40) { e->st = 0; e->t = (s16)(tmin + rnd(tmax - tmin)); }
    else { e->st = 1; e->dir = (u8)rnd(4); e->t = (s16)(30 + rnd(90)); }
  }
  if (e->st == 1) { if (!ent_move(e, DX[e->dir] * sp, DY[e->dir] * sp)) e->t = 0; }
}

/* el enderman se teletransporta cerca de (cx,cy) (en casillas) con particulas moradas */
static void ender_tp(Ent *e, int cx, int cy, int r) {
  for (int t = 0; t < 10; t++) {
    int tx = cx + rnd(2 * r + 1) - r, ty = cy + rnd(2 * r + 1) - r;
    if (iabs(tx - cx) + iabs(ty - cy) < 2) continue;
    if (!tile_walk(tx, ty) || geto(tx, ty) || getg(tx, ty) == G_LAVA || ent_tile_taken(tx, ty, e)) continue;
    fx_puff(e->x >> 4, (e->y >> 4) + 8, 5);
    e->x = tx * 256 + 128; e->y = ty * 256 + 128; e->stp = 0;
    fx_puff(e->x >> 4, (e->y >> 4) + 8, 5);
    return;
  }
}

static void ai_one(Ent *e) {
  const MobInfo *m = &MOBS[e->type];
  int ex = e->x >> 4, ey = e->y >> 4, dx = PX() - ex, dy = PY() - ey;
  int d2 = dx * dx + dy * dy, sp = m->speed;
  if (e->t2 > 0 && e->type != M_DRAGON && m->ai != AI_VILL) { if (m->ai == AI_ANIMAL) { e->t2--; if (!e->t2) e->flags &= (u8)~EF_LOVE; } }
  /* contacto */
  int touch = (iabs(dx) <= 17 && iabs(dy) < 8) || (iabs(dy) <= 17 && iabs(dx) < 8);
  switch (m->ai) {
  case AI_ANIMAL:
    if (e->aux > 0) { e->aux--; flee(e, sp + 4); break; }
    if (e->flags & EF_LOVE) {
      for (int i = 0; i < MAXENT; i++) {
        Ent *o = &ents[i];
        if (o != e && (o->flags & EF_ALIVE) && (o->flags & EF_LOVE) && o->type == e->type) {
          int ox = iabs((o->x >> 4) - ex), oy = iabs((o->y >> 4) - ey);
          if (ox < 48 && oy < 48) {
            if (ox > 12 || oy > 12) chase(e, o->x >> 4, o->y >> 4, sp);
            else {
              e->flags &= (u8)~EF_LOVE; o->flags &= (u8)~EF_LOVE;
              Ent *b = ent_spawn(e->type, ex >> 4, ey >> 4);
              if (b) { stat_bred++; add_xp(2); say("Una cria!"); }
            }
            break;
          }
        }
      }
    }
    wander(e, sp, 40, 200);
    break;
  case AI_CAT:
    if (e->flags & EF_TAME) { if (d2 > 48 * 48) chase(e, PX(), PY(), sp); else if (d2 > 24 * 24) chase(e, PX(), PY(), sp / 2); }
    else wander(e, sp, 60, 240);
    break;
  case AI_VILL: {
    int hx = (e->t2 & 255) * 16 + 8, hy = ((e->t2 >> 8) & 127) * 16 + 8;
    if (e->aux > 0) { e->aux--; flee(e, sp + 4); break; }
    if (e->t > 0) e->t--;
    if (e->t <= 0) {
      if (rnd(100) < 45) { e->st = 0; e->t = (s16)(60 + rnd(200)); }
      else { e->st = 1; e->dir = (u8)rnd(4); e->t = (s16)(30 + rnd(70)); }
      int ddx = ex - hx, ddy = ey - hy;
      if (iabs(ddx) > 100 || iabs(ddy) > 100) { e->st = 1; e->dir = (u8)(iabs(ddx) > iabs(ddy) ? (ddx > 0 ? 1 : 3) : (ddy > 0 ? 2 : 0)); }
    }
    if (e->st == 1 && !ent_move(e, DX[e->dir] * sp, DY[e->dir] * sp)) e->t = 0;
    break;
  }
  case AI_SQUID:
    if (e->t > 0) e->t--;
    if (e->t <= 0) { e->dir = (u8)rnd(4); e->t = (s16)(60 + rnd(120)); }
    if (!ent_move(e, DX[e->dir] * sp, DY[e->dir] * sp)) e->t = 0;
    break;
  case AI_ZOMBIE:
  case AI_PIGLIN:
    if (m->ai == AI_PIGLIN && has_gold_armor() && !(e->flags & EF_ANGRY)) { wander(e, sp / 2, 60, 240); break; }
    if (d2 < 130 * 130) chase(e, PX(), PY(), sp); else wander(e, sp / 2, 30, 120);
    if (e->t > 0) e->t--; else e->t = 0;
    if (touch && e->t2 <= 0) { player_hurt(m->dmg, ex, ey); e->t2 = 50; }
    if (e->t2 > 0) e->t2--;
    break;
  case AI_CREEPER:
    if (e->flags & EF_FUSE) {
      if (d2 > 80 * 80) { e->flags &= (u8)~EF_FUSE; }
      else if (--e->t2 <= 0) { e->flags = 0; explode(ex >> 4, ey >> 4, 2, 12); break; }
    } else {
      if (d2 < 110 * 110) chase(e, PX(), PY(), sp); else wander(e, sp / 2, 30, 120);
      if (d2 < 30 * 30) { e->flags |= EF_FUSE; e->t2 = 45; }
    }
    break;
  case AI_SKEL: {
    if (d2 < 150 * 150) {
      if (d2 < 48 * 48) flee(e, sp);
      else if (d2 > 90 * 90) chase(e, PX(), PY(), sp);
      if (e->t2 > 0) e->t2--;
      else if (iabs(dx) < 14 || iabs(dy) < 14) { shoot(e, 1, 52, m->dmg); e->t2 = 85; }
    } else wander(e, sp / 2, 30, 120);
    break;
  }
  case AI_ENDER:
    if (e->flags & EF_ANGRY) {
      chase(e, PX(), PY(), sp);
      if (touch && e->t2 <= 0) { player_hurt(m->dmg, ex, ey); e->t2 = 45; }
      if (e->t2 > 0) e->t2--;
      if (e->anim++ % 150 == 149 && d2 > 48 * 48) ender_tp(e, PX() >> 4, PY() >> 4, 3);
    } else {
      wander(e, sp / 3, 60, 200);
      if (d2 < 24 * 24) e->flags |= EF_ANGRY;
    }
    if (++e->anim % 200 == 199) {
      int tx = (e->x >> 8) + rnd(7) - 3, ty = (e->y >> 8) + rnd(7) - 3;
      if (tile_walk(tx, ty) && !geto(tx, ty)) { e->x = tx * 256 + 128; e->y = ty * 256 + 128; e->stp = 0; }
    }
    break;
  case AI_BLAZE:
    if (d2 < 170 * 170) {
      if (d2 < 56 * 56) flee(e, sp); else if (d2 > 90 * 90) chase(e, PX(), PY(), sp);
      if (e->t2 > 0) e->t2--; else { shoot(e, 2, 36, m->dmg); e->t2 = 90; }
    } else wander(e, sp / 2, 30, 120);
    break;
  case AI_GHAST:
    if (d2 < 220 * 220) {
      if (d2 > 110 * 110) chase(e, PX(), PY(), sp);
      if (e->t2 > 0) e->t2--; else { shoot(e, 2, 30, m->dmg); e->t2 = 150; }
    } else wander(e, sp, 30, 120);
    break;
  case AI_DRAGON: {
    boss = e;
    if (++e->t2 >= 3) { e->t2 = 0; e->aux = (u8)((e->aux + 1) & 15); }
    int tx, ty;
    if (e->st) { tx = PX(); ty = PY(); if (--e->t <= 0) e->st = 0; }
    else {
      tx = 24 * 16 + 8 + CIR[e->aux] * 2; ty = 24 * 16 + 8 + CIR[(e->aux + 12) & 15] * 2;
      if (++e->t > 420) { e->st = 1; e->t = 100; }
      if ((e->anim++ % 110) == 109) shoot(e, 2, 34, 5);
    }
    int sx = sgn(tx - ex) * sp, sy = sgn(ty - ey) * sp;
    if (iabs(tx - ex) < 4) sx = 0;
    if (iabs(ty - ey) < 4) sy = 0;
    e->x += sx; e->y += sy;
    e->dir = (u8)(sx > 0 ? 3 : 1);
    if (iabs(dx) < 20 && iabs(dy) < 20 && !(game_time & 31)) player_hurt(m->dmg, ex, ey);
    break;
  }
  default: break;
  }
  /* despawn de hostiles lejanos */
  if (hostile_ai(m->ai) && d2 > 340 * 340 && e->type != M_DRAGON) e->flags = 0;
}

void ents_update(void) {
  boss = 0;
  for (int i = 0; i < 12; i++) if (fxs[i].t > 0) { fxs[i].t--; if (fxs[i].kind == 1 && (fxs[i].t & 1)) fxs[i].y -= 16; }
  for (int i = 0; i < MAXENT; i++) {
    Ent *e = &ents[i];
    if (!(e->flags & EF_ALIVE)) continue;
    if (e->hurt) e->hurt--;
    e->anim++;
    if (e->stp) { /* avanza el paso actual */
      int ddx = e->gx - e->x, ddy = e->gy - e->y, sp = e->spd;
      e->x += ddx > sp ? sp : ddx < -sp ? -sp : ddx;
      e->y += ddy > sp ? sp : ddy < -sp ? -sp : ddy;
      if (e->x == e->gx && e->y == e->gy) e->stp = 0;
    }
    ai_one(e);
  }
}

/* ------------------------------------------------------------ aparicion */
static int rand_tile(int *ox, int *oy, int mind) {
  for (int k = 0; k < 40; k++) {
    int x = 3 + rnd(MW - 6), y = 3 + rnd(MH - 6);
    int dx = x - PTX(), dy = y - PTY();
    if (dx * dx + dy * dy < mind * mind) continue;
    if (!tile_walk(x, y) || geto(x, y) || getg(x, y) == G_LAVA) continue;
    *ox = x; *oy = y;
    return 1;
  }
  return 0;
}
static int count_t(int pred_hostile) {
  int c = 0;
  for (int i = 0; i < MAXENT; i++)
    if (ents[i].flags & EF_ALIVE) { int h = hostile_ai(MOBS[ents[i].type].ai); if (h == pred_hostile) c++; }
  return c;
}
void ents_populate(void) {
  int x, y;
  if (cur_dim == D_OVER) {
    for (int k = 0; k < 26; k++) {
      if (!rand_tile(&x, &y, 6)) continue;
      u8 g = getg(x, y);
      if (g == G_SAND) continue;
      ent_spawn(M_COW + rnd(4), x, y);
    }
    for (int v = 0; v < vill_n; v++) {
      for (int j = 0; j < 3; j++) {
        Ent *e = ent_spawn(M_VILLAGER, vill_pt[v].x - 2 + j * 2, vill_pt[v].y);
        if (e) { e->aux = (u8)((v * 2 + j) % 5); e->t2 = (s16)(((vill_pt[v].y) << 8) | vill_pt[v].x); }
      }
      ent_spawn(M_CAT, vill_pt[v].x + 1, vill_pt[v].y - 1);
    }
    for (int k = 0; k < 14; k++) {
      for (int t = 0; t < 30; t++) {
        int sx = 3 + rnd(122), sy = 3 + rnd(122);
        if (getg(sx, sy) == G_DEEP) { ent_spawn(M_SQUID, sx, sy); break; }
      }
    }
  } else if (cur_dim == D_CAVE) {
    for (int k = 0; k < 6; k++) if (rand_tile(&x, &y, 9)) ent_spawn(k & 1 ? M_SKELETON : (k & 2 ? M_CREEPER : M_ZOMBIE), x, y);
  } else if (cur_dim == D_NETH) {
    for (int k = 0; k < 5; k++) if (rand_tile(&x, &y, 9)) ent_spawn(getg(x, y) == G_NBF ? M_BLAZE : M_PIGLIN, x, y);
    for (int k = 0; k < 3; k++) if (rand_tile(&x, &y, 9)) ent_spawn(M_ENDERMAN, x, y);
    for (int k = 0; k < 3; k++) { int fx = 24 + rnd(22), fy = 10 + rnd(12); if (tile_walk(fx, fy) && !geto(fx, fy)) ent_spawn(M_BLAZE, fx, fy); }
    for (int k = 0; k < 2; k++) if (rand_tile(&x, &y, 12)) ent_spawn(M_GHAST, x, y);
  } else {
    if (!P.won) { Ent *d = ent_spawn(M_DRAGON, 24, 12); if (d) d->t2 = 0; }
    for (int k = 0; k < 4; k++) if (rand_tile(&x, &y, 6)) ent_spawn(M_ENDERMAN, x, y);
  }
}

int dark_level_ambient(void) {
  if (cur_dim == D_CAVE) return 3;
  if (cur_dim == D_NETH) return 2;
  if (cur_dim == D_END) return 1;
  u32 p = day_t * 100 / DAY_LEN;
  if (p < 50) return 0;
  if (p < 58) return 1;
  if (p < 66) return 2;
  if (p < 88) return 3;
  if (p < 94) return 2;
  if (p < 98) return 1;
  return 0;
}

static int scan_cur;
void sim_world(void) {
  game_time++;
  day_t++; if (day_t >= DAY_LEN) day_t = 0;
  tnt_update();
  /* cultivos: barrido de 128 casillas por frame */
  int total = MW * MH, base = DOFF[cur_dim];
  for (int k = 0; k < 128; k++) {
    if (scan_cur >= total) scan_cur = 0;
    int idx = base + scan_cur;
    u8 o = wo[idx];
    if ((o >= O_WHEAT0 && o < O_WHEAT3) || (o >= O_CARROT0 && o < O_CARROT3)) {
      int x = scan_cur % MW, y = scan_cur / MW, mult = 1;
      if (wg[idx] == G_SOILW) mult = 2;
      if (rs_sprinkler_near(x, y)) mult *= 3;
      if (rnd(30) < mult) seto(x, y, (u8)(o + 1));
    }
    scan_cur++;
  }
  /* aparicion de mobs cada 2 s */
  if ((game_time % 120) == 7) {
    int x, y, amb = dark_level_ambient();
    int hostiles = count_t(1), total_e = hostiles + count_t(0);
    if (total_e < MAXENT - 4) {
      if (cur_dim == D_OVER) {
        if (amb >= 2 && hostiles < (diff_hard ? 10 : 7) && rand_tile(&x, &y, 9)) { int r = rnd(5); ent_spawn(r == 0 ? M_ZOMBIE : r == 1 ? M_CREEPER : r == 2 ? M_SKELETON : r == 3 ? M_ENDERMAN : (rnd(2) ? M_ZOMBIE : M_SKELETON), x, y); }
        else if (amb == 0 && count_t(0) < 26 && rand_tile(&x, &y, 10)) { u8 g = getg(x, y); if (g == G_GRASS || g == G_DIRT || g == G_SNOW || g == G_JGRASS) ent_spawn(M_COW + rnd(4), x, y); }
      } else if (cur_dim == D_CAVE) {
        if (hostiles < 8 && rand_tile(&x, &y, 9)) { int r = rnd(3); ent_spawn(r == 0 ? M_ZOMBIE : r == 1 ? M_CREEPER : M_SKELETON, x, y); }
      } else if (cur_dim == D_NETH) {
        if (hostiles < 8 && rand_tile(&x, &y, 10)) ent_spawn(getg(x, y) == G_NBF ? M_BLAZE : (rnd(3) == 0 ? M_ENDERMAN : M_PIGLIN), x, y);
      } else if (hostiles < 6 && rand_tile(&x, &y, 7)) ent_spawn(M_ENDERMAN, x, y);
    }
  }
}
