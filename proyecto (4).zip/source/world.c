/* world.c - generacion procedural (ruido entero, sin float) y acceso al mapa */
#include "game.h"

const u8 DW[NDIM] = {128, 64, 64, 48};
const u8 DH[NDIM] = {128, 64, 64, 48};
const u16 DOFF[NDIM] = {0, 16384, 20480, 24576};

u8 wg[TOTAL] EWRAM;
u8 wo[TOTAL] EWRAM;
u8 wst[TOTAL] EWRAM;
u8 wrs[TOTAL] EWRAM;
u8 wdirty[TOTAL / 8 + 1] EWRAM;
int cur_dim;
u32 world_seed;
Pt spawn_pt[NDIM];
Pt door_pt[3], exit_pt[3];
Pt vill_pt[4];
int vill_n;
Pt portal_over;
void (*tile_hook)(int x, int y);

/* ------------------------------------------------------------------ azar */
static u32 rng_s = 12345;
void rnd_seed(u32 s) { rng_s = s ? s : 1; }
u32 rnd32(void) {
  rng_s ^= rng_s << 13;
  rng_s ^= rng_s >> 17;
  rng_s ^= rng_s << 5;
  return rng_s;
}
int rnd(int n) { return (int)((rnd32() >> 8) % (u32)n); }

static u32 hsh(u32 x, u32 y, u32 s) {
  u32 h = x * 374761393u + y * 668265263u + s * 2246822519u;
  h = (h ^ (h >> 13)) * 1274126177u;
  return h ^ (h >> 16);
}
int hash_xy(int x, int y, int s) { return (int)(hsh((u32)x, (u32)y, (u32)s) & 1023); }
static int vn(int x, int y, int sh, u32 s) {
  int mask = (1 << sh) - 1, gx = x >> sh, gy = y >> sh;
  int fx = ((x & mask) << 8) >> sh, fy = ((y & mask) << 8) >> sh;
  fx = (fx * fx * (768 - 2 * fx)) >> 16;
  fy = (fy * fy * (768 - 2 * fy)) >> 16;
  int a = (int)(hsh((u32)gx, (u32)gy, s) & 255), b = (int)(hsh((u32)gx + 1, (u32)gy, s) & 255);
  int c = (int)(hsh((u32)gx, (u32)gy + 1, s) & 255), d = (int)(hsh((u32)gx + 1, (u32)gy + 1, s) & 255);
  int top = a + (((b - a) * fx) >> 8), bot = c + (((d - c) * fx) >> 8);
  return top + (((bot - top) * fy) >> 8);
}
static int fbm(int x, int y, u32 s) { return (vn(x, y, 4, s) * 4 + vn(x, y, 3, s + 1) * 2 + vn(x, y, 2, s + 2)) / 7; }

/* ---------------------------------------------------------------- acceso */
int tinb(int x, int y) { return x >= 0 && y >= 0 && x < DW[cur_dim] && y < DH[cur_dim]; }
int tidx(int x, int y) { return DOFF[cur_dim] + y * DW[cur_dim] + x; }
u8 getg(int x, int y) { return tinb(x, y) ? wg[tidx(x, y)] : G_VOID; }
u8 geto(int x, int y) { return tinb(x, y) ? wo[tidx(x, y)] : O_MTN; }
static void mark(int i) { wdirty[i >> 3] |= (u8)(1 << (i & 7)); }
void setg(int x, int y, u8 v) {
  if (!tinb(x, y)) return;
  int i = tidx(x, y);
  if (wg[i] == v) return;
  wg[i] = v; mark(i);
  if (tile_hook) tile_hook(x, y);
}
void seto(int x, int y, u8 v) {
  if (!tinb(x, y)) return;
  int i = tidx(x, y);
  wo[i] = v; mark(i);
  if (tile_hook) tile_hook(x, y);
}
int is_water(int x, int y) {
  u8 g = getg(x, y);
  return g == G_WATER || g == G_DEEP;
}
int tile_walk(int x, int y) {
  if (!tinb(x, y)) return 0;
  int i = tidx(x, y);
  u8 g = wg[i], o = wo[i];
  if (g == G_VOID || g == G_WATER || g == G_DEEP) return 0;
  if (o && !(BLK[o].flags & BF_WALK)) return 0;
  return 1;
}

#define IX(d, x, y) (DOFF[d] + (y) * DW[d] + (x))
static void rawo(int d, int x, int y, u8 v) {
  if (x >= 0 && y >= 0 && x < DW[d] && y < DH[d]) wo[IX(d, x, y)] = v;
}
static void rawg(int d, int x, int y, u8 v) {
  if (x >= 0 && y >= 0 && x < DW[d] && y < DH[d]) wg[IX(d, x, y)] = v;
}
void seto_raw(int d, int x, int y, u8 v) { rawo(d, x, y, v); }
static u8 gg(int d, int x, int y) { return (x >= 0 && y >= 0 && x < DW[d] && y < DH[d]) ? wg[IX(d, x, y)] : G_VOID; }
static u8 go(int d, int x, int y) { return (x >= 0 && y >= 0 && x < DW[d] && y < DH[d]) ? wo[IX(d, x, y)] : O_MTN; }
static void clear_area(int d, int x0, int y0, int w, int h, u8 g) {
  for (int y = y0; y < y0 + h; y++)
    for (int x = x0; x < x0 + w; x++) { rawg(d, x, y, g); rawo(d, x, y, 0); }
}
static int land_ok(int x, int y) {
  u8 g = gg(D_OVER, x, y);
  return g != G_WATER && g != G_DEEP && g != G_VOID && go(D_OVER, x, y) != O_MTN;
}

/* ---------------------------------------------------------------- aldeas */
static void build_house(int hx, int hy, int dside) {
  for (int y = 0; y < 5; y++)
    for (int x = 0; x < 5; x++) {
      int edge = x == 0 || y == 0 || x == 4 || y == 4;
      rawg(D_OVER, hx + x, hy + y, G_WOOD);
      rawo(D_OVER, hx + x, hy + y, edge ? O_PLANK : 0);
    }
  int dx = dside == 0 ? 2 : dside == 2 ? 2 : dside == 1 ? 0 : 4;
  int dy = dside == 0 ? 4 : dside == 2 ? 0 : 2;
  rawo(D_OVER, hx + dx, hy + dy, 0);
  rawg(D_OVER, hx + dx, hy + dy, G_PATH);
  int by = dside == 2 ? 3 : 1;
  rawo(D_OVER, hx + 1, hy + by, O_BED);
  rawo(D_OVER, hx + 3, hy + by, O_CHEST);
  rawo(D_OVER, hx + (dside == 1 ? 3 : 1), hy + (dside == 2 ? 1 : 3), O_TORCH);
}
static void build_village(int cx, int cy, int k) {
  clear_area(D_OVER, cx - 9, cy - 9, 19, 19, G_GRASS);
  for (int i = -9; i <= 9; i++) {
    rawg(D_OVER, cx + i, cy, G_PATH);
    rawg(D_OVER, cx, cy + i, G_PATH);
  }
  rawo(D_OVER, cx, cy, O_WELL);
  build_house(cx - 8, cy - 7, 0);
  build_house(cx + 4, cy - 7, 0);
  build_house(cx - 8, cy + 3, 2);
  /* granja */
  for (int y = 0; y < 5; y++)
    for (int x = 0; x < 6; x++) {
      int px = cx + 3 + x, py = cy + 3 + y;
      rawg(D_OVER, px, py, (y == 2) ? G_SOILW : G_SOIL);
      if (y != 2) rawo(D_OVER, px, py, (hash_xy(px, py, 5) & 1) ? O_WHEAT3 : O_CARROT3);
    }
  rawo(D_OVER, cx + 2, cy + 3, O_TORCH);
  if (vill_n < 4) { vill_pt[vill_n].x = cx; vill_pt[vill_n].y = cy + 1; vill_n++; }
  (void)k;
}

/* ------------------------------------------------------------ superficie */
static void gen_over(u32 sd) {
  const int d = D_OVER, w = 128, h = 128, cx = 64, cy = 64;
  for (int y = 0; y < h; y++)
    for (int x = 0; x < w; x++) {
      int i = IX(d, x, y);
      int e = fbm(x, y, sd), dx = x - cx, dy = y - cy, d2 = dx * dx + dy * dy;
      int temp = vn(x, y, 5, sd + 11), moist = vn(x, y, 5, sd + 12);
      int bio = 0; /* 1 desierto 2 nieve 3 jungla */
      u8 g = G_GRASS, o = 0;
      if (temp > 165 && moist < 125) bio = 1;
      else if (temp < 72) bio = 2;
      else if (moist > 170 && temp > 110) bio = 3;
      if (bio == 1) g = G_SAND;
      else if (bio == 2) g = G_SNOW;
      else if (bio == 3) g = G_JGRASS;
      else if (vn(x, y, 2, sd + 3) > 190) g = G_DIRT;
      if (e < 94 && d2 > 49) g = e < 80 ? G_DEEP : G_WATER;
      else if (e < 103 && d2 > 49) g = G_SAND;
      int land = (g != G_WATER && g != G_DEEP);
      int hv = hash_xy(x, y, (int)sd + 5);
      if (e > 170 && d2 > 100) { o = O_MTN; g = G_GRASS; }
      else if (land && g != G_SAND && d2 > 9) {
        int forest = fbm(x + 100, y, sd + 11) > 140;
        int th = forest ? 140 : 15; /* de 1024 */
        if (bio == 3) th = 190;
        if (hv < th) o = bio == 2 ? O_PINE : bio == 3 ? O_JTREE : O_TREE;
        else if (g == G_GRASS && hv > 1000) g = G_GRASSF1;
        else if (g == G_GRASS && hv > 990) g = G_GRASSF2;
      } else if (bio == 1 && land && g == G_SAND && d2 > 9 && e > 112 && hv < 20) o = O_CACTUS;
      else if (!land) {
        if (e < 80 && hv < 30) o = O_KELP;
        else if (e < 90 && hv < 50) o = O_SEAGR;
        else if (e < 88 && hv > 1010) o = (u8)(O_CORALR + (hv & 3));
      }
      if (x < 2 || y < 2 || x >= w - 2 || y >= h - 2) { o = O_MTN; g = G_GRASS; }
      wg[i] = g; wo[i] = o;
    }
  /* colinas con puertas a las cuevas */
  int placed = 0;
  for (int t = 0; t < 60 && placed < 3; t++) {
    int x0 = 8 + (int)(hsh((u32)t, 1, sd) % 100), y0 = 8 + (int)(hsh((u32)t, 2, sd) % 100);
    int ok = 1, ddx = x0 + 4 - cx, ddy = y0 + 2 - cy;
    if (ddx * ddx + ddy * ddy < 400) ok = 0;
    for (int k = 0; k < placed && ok; k++) { int ex = door_pt[k].x - x0 - 4, ey = door_pt[k].y - y0 - 4; if (ex * ex + ey * ey < 700) ok = 0; }
    for (int y = y0 - 1; y < y0 + 7 && ok; y++) for (int x = x0 - 1; x < x0 + 10 && ok; x++) if (!land_ok(x, y)) ok = 0;
    if (!ok) continue;
    for (int y = y0; y < y0 + 5; y++) for (int x = x0; x < x0 + 9; x++) { rawo(d, x, y, O_MTN); rawg(d, x, y, G_GRASS); }
    for (int x = x0 - 1; x < x0 + 10; x++) for (int y = y0 + 5; y < y0 + 7; y++) { if (land_ok(x, y)) rawo(d, x, y, 0); }
    rawo(d, x0 + 4, y0 + 4, O_DOOR);
    rawg(d, x0 + 4, y0 + 5, G_PATH);
    door_pt[placed].x = x0 + 4; door_pt[placed].y = y0 + 4;
    placed++;
  }
  while (placed < 3) { door_pt[placed].x = 20 + placed * 8; door_pt[placed].y = 20; clear_area(d, 20 + placed * 8 - 1, 19, 3, 3, G_GRASS); rawo(d, 20 + placed * 8, 20, O_DOOR); placed++; }
  /* aldeas */
  vill_n = 0;
  for (int t = 0; t < 600 && vill_n < 3; t++) {
    int x0 = 14 + (int)(hsh((u32)t, 3, sd) % 100), y0 = 14 + (int)(hsh((u32)t, 4, sd) % 100);
    int ok = 1, ddx = x0 - cx, ddy = y0 - cy;
    if (ddx * ddx + ddy * ddy < 250) ok = 0;
    for (int k = 0; k < vill_n && ok; k++) { int ex = vill_pt[k].x - x0, ey = vill_pt[k].y - y0; if (ex * ex + ey * ey < 900) ok = 0; }
    for (int k = 0; k < 3 && ok; k++) { int ex = door_pt[k].x - x0, ey = door_pt[k].y - y0; if (ex * ex + ey * ey < 250) ok = 0; }
    { int bad = 0; for (int y = y0 - 9; y <= y0 + 9; y += 3) for (int x = x0 - 9; x <= x0 + 9; x += 3) if (!land_ok(x, y)) bad++; if (bad > 3) ok = 0; }
    if (ok) build_village(x0, y0, vill_n);
  }
  clear_area(d, cx - 1, cy - 1, 3, 3, G_GRASS);
  spawn_pt[D_OVER].x = cx; spawn_pt[D_OVER].y = cy;
}

/* ----------------------------------------------------------------- cueva */
static void gen_cave(u32 sd) {
  const int d = D_CAVE, w = 64, h = 64;
  static const int ex[3] = {8, 55, 9}, ey[3] = {8, 8, 54};
  for (int y = 0; y < h; y++)
    for (int x = 0; x < w; x++) {
      int i = IX(d, x, y);
      wg[i] = G_CAVE; wo[i] = 0;
      if (x < 2 || y < 2 || x >= w - 2 || y >= h - 2) { wo[i] = O_CAVEW; continue; }
      int n = fbm(x, y, sd + 21), dc = 99999;
      for (int k = 0; k < 3; k++) { int dx = x - ex[k], dy = y - ey[k], q = dx * dx + dy * dy; if (q < dc) dc = q; }
      int hv = hash_xy(x, y, (int)sd + 31);
      if (n > 118 && dc > 25) {
        u8 o = O_STONE;
        if (hv < 70) o = O_COAL;
        else if (hv < 105) o = O_IRON;
        else if (hv < 118 && y > 20) o = O_DIAM;
        else if (hv < 150 && y > 14) o = O_RORE;
        else if (hv < 160) o = O_LAPIS;
        wo[i] = o;
      } else if (dc > 64) {
        if (fbm(x + 30, y, sd + 41) > 165) wg[i] = G_WATER;
        else if (y > 16 && fbm(x, y + 70, sd + 51) > 160) wg[i] = G_LAVA;
        else if (hv > 1005) wo[i] = O_COBWEB;
      }
    }
  for (int k = 0; k < 3; k++) {
    clear_area(d, ex[k] - 3, ey[k] - 3, 7, 7, G_CAVE);
    rawo(d, ex[k], ey[k], O_EXIT);
    exit_pt[k].x = ex[k]; exit_pt[k].y = ey[k];
    rawo(d, ex[k] - 2, ey[k] - 2, O_TORCH);
  }
  /* fortaleza con el portal del End */
  int sx = 44, sy = 42;
  clear_area(d, sx - 6, sy - 6, 13, 13, G_SBF);
  for (int i = -6; i <= 6; i++) { rawo(d, sx + i, sy - 6, O_SBW); rawo(d, sx + i, sy + 6, O_SBW); rawo(d, sx - 6, sy + i, O_SBW); rawo(d, sx + 6, sy + i, O_SBW); }
  rawo(d, sx, sy + 6, 0); rawo(d, sx - 1, sy + 6, 0); rawo(d, sx + 1, sy + 6, 0);
  for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) if (dx || dy) rawo(d, sx + dx, sy + dy, O_FRAME);
  rawo(d, sx - 4, sy - 4, O_CHEST); rawo(d, sx + 4, sy - 4, O_CHEST);
  rawo(d, sx - 4, sy + 4, O_TORCH); rawo(d, sx + 4, sy + 4, O_TORCH);
  rawo(d, sx - 2, sy - 3, O_DSPAWN); rawo(d, sx + 2, sy - 3, O_DSPAWN);
  spawn_pt[D_CAVE].x = ex[0]; spawn_pt[D_CAVE].y = ey[0] + 2;
}

/* ---------------------------------------------------------------- nether */
static void gen_neth(u32 sd) {
  const int d = D_NETH, w = 64, h = 64;
  for (int y = 0; y < h; y++)
    for (int x = 0; x < w; x++) {
      int i = IX(d, x, y);
      wg[i] = G_NETH; wo[i] = 0;
      if (x < 2 || y < 2 || x >= w - 2 || y >= h - 2) { wo[i] = O_NBW; continue; }
      int n = fbm(x, y, sd + 61), hv = hash_xy(x, y, (int)sd + 62);
      int dx = x - 8, dy = y - 52, d2 = dx * dx + dy * dy;
      if (d2 < 49) continue;
      if (fbm(x + 40, y, sd + 63) > 150) wg[i] = G_LAVA;
      else if (n > 126) {
        u8 o = O_NRACK;
        if (hv < 22) o = O_QORE;
        else if (hv < 34) o = O_NGOLD;
        else if (hv < 38 && y > 30) o = O_DEBRIS;
        else if (hv < 52) o = O_GLOWS;
        else if (hv < 62) o = O_BASALT;
        wo[i] = o;
      } else if (n > 108 && hv < 70) wo[i] = (hv & 1) ? O_CTREE : O_WTREE;
      else if (hv > 1012) wo[i] = O_SOULF;
      else if (hv > 1005) wo[i] = O_MAGMA;
    }
  /* fortaleza de ladrillo */
  int fx0 = 22, fy0 = 8, fw = 26, fh = 16;
  clear_area(d, fx0, fy0, fw, fh, G_NBF);
  for (int x = fx0; x < fx0 + fw; x++) { rawo(d, x, fy0, O_BRICK); rawo(d, x, fy0 + fh - 1, O_BRICK); }
  for (int y = fy0; y < fy0 + fh; y++) { rawo(d, fx0, y, O_BRICK); rawo(d, fx0 + fw - 1, y, O_BRICK); }
  for (int y = fy0 + 1; y < fy0 + fh - 1; y++) { rawo(d, fx0 + 8, y, (y % 5 == 2) ? 0 : O_BRICK); rawo(d, fx0 + 17, y, (y % 5 == 4) ? 0 : O_BRICK); }
  rawo(d, fx0 + 12, fy0, 0); rawo(d, fx0 + 12, fy0 + fh - 1, 0); rawo(d, fx0, fy0 + 6, 0); rawo(d, fx0 + fw - 1, fy0 + 9, 0);
  rawo(d, fx0 + 3, fy0 + 3, O_CHEST); rawo(d, fx0 + 21, fy0 + 12, O_CHEST);
  for (int k = 0; k < 6; k++) { rawg(d, fx0 + 10 + k, fy0 + 7, G_SOIL); rawo(d, fx0 + 10 + k, fy0 + 7, O_WART); }
  rawo(d, fx0 + 12, fy0 + 3, O_LANTERN); rawo(d, fx0 + 12, fy0 + 12, O_LANTERN);
  /* portal de regreso */
  clear_area(d, 5, 49, 7, 7, G_NETH);
  for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) rawo(d, 8 + dx, 52 + dy, (dx || dy) ? O_OBS : O_NPORTAL);
  spawn_pt[D_NETH].x = 8; spawn_pt[D_NETH].y = 55;
}

/* ------------------------------------------------------------------- end */
static void gen_end(u32 sd) {
  const int d = D_END, w = 48, h = 48, cx = 24, cy = 24;
  for (int y = 0; y < h; y++)
    for (int x = 0; x < w; x++) {
      int i = IX(d, x, y);
      int dx = x - cx, dy = y - cy, d2 = dx * dx + dy * dy;
      wg[i] = G_VOID; wo[i] = 0;
      if (d2 <= 19 * 19) {
        wg[i] = G_END;
        if (d2 > 17 * 17 || (x < 1) || y < 1) { if (hash_xy(x, y, (int)sd) < 500) wo[i] = O_ENDST; }
        else if (d2 > 10 * 10 && hash_xy(x, y, (int)sd + 7) < 18) wo[i] = O_CHORUS;
        else if (d2 > 10 * 10 && hash_xy(x, y, (int)sd + 9) < 10) wo[i] = O_PURPUR;
      }
    }
  static const int pxs[6] = {24, 30, 33, 30, 18, 15}, pys[6] = {16, 18, 24, 31, 31, 24};
  for (int k = 0; k < 6; k++) for (int dy = 0; dy < 2; dy++) for (int dx = 0; dx < 2; dx++) rawo(d, pxs[k] + dx, pys[k] + dy - (k == 0 ? 0 : 0), O_OBS);
  clear_area(d, 22, 22, 5, 5, G_END);
  spawn_pt[D_END].x = 24; spawn_pt[D_END].y = 38;
  clear_area(d, 22, 36, 5, 4, G_END);
}

void world_gen(u32 seed) {
  world_seed = seed;
  for (int i = 0; i < TOTAL; i++) { wg[i] = 0; wo[i] = 0; wst[i] = 0; wrs[i] = 0; }
  for (int i = 0; i < TOTAL / 8 + 1; i++) wdirty[i] = 0;
  rnd_seed(seed ^ 0x9E3779B9u);
  gen_over(seed);
  gen_cave(seed);
  gen_neth(seed);
  gen_end(seed);
  portal_over.x = -1;
  for (int i = 0; i < TOTAL / 8 + 1; i++) wdirty[i] = 0;
}
