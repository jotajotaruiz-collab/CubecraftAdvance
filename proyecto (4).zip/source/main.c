/* main.c - bucle principal, pantalla de titulo y entrada/salida GBA */
#include "game.h"

enum { ST_TITLE, ST_PLAY };
static int state;
static u16 prev_keys;
static int title_cur, title_frames;
static int tscroll;

#ifndef HOST
void vsync(void) {
  while (REG_VCOUNT >= 160) {}
  while (REG_VCOUNT < 160) {}
}
u16 keys_now(void) { return (u16)(~REG_KEYINPUT & 0x3FF); }
#endif


static int prev3d;
static void apply2d(void) { /* vuelve a la configuracion de fondos de la vista 2D */
  REG_BG0CNT = BGCNT(3, 0, 1, SB_OBJ, 0);
  REG_BG1CNT = BGCNT(3, 0, 1, SB_GND, 0);
  REG_BG2CNT = BGCNT(0, 3, 0, SB_HUD, 0);
  REG_BG3CNT = BGCNT(1, 3, 0, SB_DARK, 0);
  REG_BLDCNT = 0x3348;
  REG_BLDALPHA = (u16)(12 | (4 << 8));
  map_dirty = 15;
  render_full_redraw();
  gfx_flush_maps();
}

static void frame_end(int sx, int sy) {
  int play = (state == ST_PLAY), menu = play && menu_kind != MN_NONE, d3 = play && v3d_on;
  vsync();
  if (d3) map_dirty &= 8; /* en 3D solo el HUD usa mapas de texto; BG2 es el suelo afin */
  gfx_flush_maps();
  oam_flush();
  if (d3) {
    v3d_vblank(!menu);
    REG_BG0CNT = BGCNT(0, 3, 0, SB_HUD, 0);
    REG_BG2CNT = (u16)(3 | (30 << 8) | 0x2000 | (2 << 14)); /* afin 64x64 tiles, con repeticion */
    REG_BLDCNT = menu ? 0 : 0x2044; /* BG2 (suelo) contra el cielo: niebla */
    REG_BG0HOFS = 0; REG_BG0VOFS = 0;
    REG_DISPCNT = (u16)(DCNT_MODE1 | DCNT_OBJ_1D | DCNT_OBJ | DCNT_BG0 | (menu ? 0 : DCNT_BG2));
    if (menu) PAL[0] = 0x1442;
    prev3d = 1;
    ui_update_tint(menu);
    if (!menu && (game_time % 20) == 0) gfx_anim((int)(game_time / 20));
    return;
  }
  if (prev3d) { v3d_vblank(0); apply2d(); prev3d = 0; }
  REG_BG0HOFS = (u16)sx; REG_BG0VOFS = (u16)sy;
  REG_BG1HOFS = (u16)sx; REG_BG1VOFS = (u16)sy;
  REG_BG3HOFS = (u16)sx; REG_BG3VOFS = (u16)sy;
  REG_BG2HOFS = 0; REG_BG2VOFS = 0;
  REG_DISPCNT = (u16)(DCNT_MODE0 | DCNT_OBJ_1D | DCNT_BG2 | DCNT_OBJ | (menu ? 0 : (DCNT_BG0 | DCNT_BG1 | DCNT_BG3)));
  PAL[0] = menu ? 0x1442 : 0;
  ui_update_tint(!play || menu);
  if (play && menu_kind == MN_NONE && (game_time % 20) == 0) gfx_anim((int)(game_time / 20));
}

/* ---------------------------------------------------------------- titulo */
static const char *TMENU[5] = {"Nueva: Supervivencia", "Nueva: Creativo", "Nueva: Hardcore", "Continuar ranura 1", "Continuar ranura 2"};

static void title_bg(void) {
  for (int y = 0; y < 16; y++)
    for (int x = 0; x < 16; x++) {
      int h = hash_xy(x, y, 77);
      u8 g = G_GRASS, o = 0;
      if (y >= 11 && y <= 13) g = (h & 3) ? G_WATER : G_SAND;
      else if (y == 10 || y == 14) g = G_SAND;
      else { if (h < 120) o = O_TREE; else if (h < 150) g = G_GRASSF1; else if (h < 180) g = G_GRASSF2; else if (h < 200) o = O_STONE; }
      mt_put(map_gnd, x, y, gfx_ground_slot(g), 0, 0);
      u8 hf = 0, vf = 0;
      int os = 0;
      if (o) os = gfx_obj_slot(o, 0, 0, &hf, &vf);
      mt_put(map_obj, x, y, os, 0, 0);
      mt_put(map_dark, x, y, 0, 0, 0);
    }
}
static void title_draw(void) {
  hud_clear();
  for (int y = 1; y < 8; y++) for (int x = 3; x < 27; x++) { u16 *p = &map_hud[y * 32 + x]; *p = T_PANEL | (15 << 12); }
  for (int x = 3; x < 27; x++) { map_hud[1 * 32 + x] = T_BORDER | (15 << 12); map_hud[7 * 32 + x] = T_BORDER | (15 << 12); }
  hud_text(7, 2, "C U B I C R A F T");
  hud_text(11, 4, "R P G");
  hud_text(5, 6, "Adaptacion para Game Boy Advance");
  for (int y = 9; y < 20; y++) for (int x = 4; x < 26; x++) map_hud[y * 32 + x] = T_PANEL | (15 << 12);
  for (int i = 0; i < 5; i++) {
    int ex = i < 3 ? 1 : save_exists(i - 3);
    hud_text(7, 10 + i * 2, ex ? TMENU[i] : (i == 3 ? "Ranura 1 (vacia)" : "Ranura 2 (vacia)"));
  }
  hud_text(5, 10 + title_cur * 2, ">");
  hud_text(5, 19, "A: elegir  Arriba/Abajo");
  map_dirty |= 8;
}
static void start_play(void) {
  tile_hook = render_tile;
  ents_clear();
  ents_populate();
  rs_neighbor_changed(-1, -1);
  render_full_redraw();
  hud_clear();
  menu_kind = MN_NONE;
  state = ST_PLAY;
  diff_hard = (P.mode == MODE_HARD);
  msg_t = 0;
  say(P.mode == MODE_CREATIVE ? "Modo creativo" : "Bienvenido!");
}
static void title_update(u16 pressed) {
  title_frames++;
  tscroll++;
  if (pressed & KEY_UP) title_cur = (title_cur + 4) % 5;
  if (pressed & KEY_DOWN) title_cur = (title_cur + 1) % 5;
  if (pressed & KEY_A) {
    u32 seed = (u32)title_frames * 2654435761u + 12345u;
    if (title_cur < 3) {
      world_gen(seed);
      player_init(title_cur);
      cur_slot = 0;
      start_play();
      return;
    }
    if (load_game(title_cur - 3)) { start_play(); return; }
  }
  title_draw();
  oam_clear();
  frame_end(tscroll >> 1, 0);
}

void game_init(void) {
  gfx_init();
  title_bg();
  state = ST_TITLE;
  prev_keys = 0xFFFF;
  title_cur = 0;
  rnd_seed(0xC0FFEE);
}

int render_scroll_x(void);
int render_scroll_y(void);

/* en 3D las flechas van relativas a la camara: direccion de mundo = (pantalla + giro) & 3 */
static u16 remap_dirs(u16 k) {
  int q = v3d_yaw_view();
  if (!q) return k;
  u16 out = (u16)(k & ~(KEY_UP | KEY_DOWN | KEY_LEFT | KEY_RIGHT));
  static const u16 BIT[4] = {KEY_DOWN, KEY_LEFT, KEY_UP, KEY_RIGHT}; /* 0 abajo 1 izq 2 arriba 3 der */
  for (int d = 0; d < 4; d++) if (k & BIT[d]) out |= BIT[(d + q) & 3];
  return out;
}

void game_frame(void) {
  u16 held = keys_now();
  u16 pressed = (u16)(held & ~prev_keys);
  prev_keys = held;
  if (state == ST_TITLE) { title_update(pressed); return; }
  if (menu_kind != MN_NONE) {
    int r = ui_update(pressed, held);
    if (r == 2) {
      state = ST_TITLE; title_bg(); title_cur = 0; prev_keys = 0xFFFF;
      for (int i = 0; i < 16; i++) { REG_BG0HOFS = 0; }
      return;
    }
    oam_clear();
    ui_menu_sprites();
    frame_end(0, 0);
    return;
  }
  if (pressed & KEY_START) { ui_open(MN_PAUSE, 0); frame_end(0, 0); return; }
  if ((pressed & KEY_SELECT) && v3d_on) v3d_turn(1);
  else if (pressed & KEY_SELECT) { ui_open(MN_MAP, 0); frame_end(0, 0); return; }
  {
    /* L+R (casi a la vez) en creativo: activa/desactiva el vuelo; solo L o R cambia la casilla */
    static int lr_t, lr_key, lr_sel;
    int k = pressed & (KEY_L | KEY_R);
    if (k) {
      if (P.mode == MODE_CREATIVE && k == (KEY_L | KEY_R)) { player_set_fly(!P.fly); lr_t = 0; }
      else if (P.mode == MODE_CREATIVE && lr_t > 0 && lr_key != k) { P.sel = (u8)lr_sel; player_set_fly(!P.fly); lr_t = 0; }
      else {
        lr_sel = P.sel; lr_key = k; lr_t = 8;
        if (k & KEY_L) P.sel = (u8)((P.sel + 8) % 9);
        if (k & KEY_R) P.sel = (u8)((P.sel + 1) % 9);
      }
    }
    if (lr_t > 0) lr_t--;
  }
  {
    static u8 last_sel = 255;
    if (P.sel != last_sel) { if (last_sel != 255 && inv[P.sel].id) say(item_name(inv[P.sel].id)); last_sel = P.sel; }
  }
  if (v3d_on) { held = remap_dirs(held); pressed = remap_dirs(pressed); } /* el D-pad es relativo a la camara */
  if (held & KEY_A) action_a();
  if (pressed & KEY_B) use_item_b();
  player_update(held, pressed);
  ents_update();
  projs_update();
  sim_world();
  if ((game_time % 6) == 0) rs_tick();
  if ((game_time % 60) == 30) check_achievements();
  if (P.dead) { ui_open(MN_DEAD, 0); frame_end(0, 0); return; }
  render_world();
  frame_end(render_scroll_x(), render_scroll_y());
}

#ifndef HOST
int main(void) {
  REG_WAITCNT = 0x4317;
  game_init();
  for (;;) game_frame();
  return 0;
}
#endif
