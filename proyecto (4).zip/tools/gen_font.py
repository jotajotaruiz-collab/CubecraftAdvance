#!/usr/bin/env python3
"""Genera source/font.h (fuente 8x8, ASCII 32..126) a partir de DejaVu Sans Bold (9 px, 1 bit).
Los glifos que no caben en 8 px usan la variante Condensed; los que tienen rabo se suben 1 px.
El resultado ya esta incluido en el repo; no hace falta ejecutarlo para compilar."""
from PIL import Image, ImageDraw, ImageFont
import sys
base = "/usr/share/fonts/truetype/dejavu/"
f1 = ImageFont.truetype(base + "DejaVuSans-Bold.ttf", 9)
f2 = ImageFont.truetype(base + "DejaVuSansCondensed-Bold.ttf", 9)
out = ["/* Generado por tools/gen_font.py : 95 glifos 8x8, 1bpp, bit7 = pixel izquierdo */",
       "static const unsigned char font8x8[95][8] = {"]
for c in range(32, 127):
    ch = chr(c)
    f = f1
    if f1.getlength(ch) > 7.4: f = f2
    w = f.getlength(ch)
    im = Image.new("L", (16, 16), 0)
    d = ImageDraw.Draw(im); d.fontmode = "1"
    ox = max(0, int((8 - w) // 2)) if ch != " " else 0
    oy = 8 if ch in "gjpqy,;Q" else 9  # mayusculas en filas 1..7; los rabos se suben 1 fila
    d.text((ox, oy), ch, font=f, fill=255, anchor="ls")
    rows = []
    for y in range(8):
        b = 0
        for x in range(8):
            if im.getpixel((x, y + 1)) > 127: b |= 0x80 >> x
        rows.append(b)
    out.append("  {" + ",".join("0x%02X" % r for r in rows) + "}, /* '%s' */" % (ch if ch not in "\\*/" else "?"))
out.append("};")
open("source/font.h", "w").write("\n".join(out) + "\n")
