/* test.c - pruebas de humo de las mecanicas (se ejecuta en PC con el mismo codigo del juego) */
#define main host_main
#include "host.c"
#undef main
static int fails;
#define CHECK(c, msg) do { if (!(c)) { printf("FALLA: %s\n", msg); fails++; } else printf("ok: %s\n", msg); } while (0)
int main(void) {
  game_init(); step(5, 0); step(1, KEY_A); step(3, 0);
  /* minar un arbol */
  int tx = -1, ty = -1;
  for (int r = 2; r < 30 && tx < 0; r++) for (int dx = -r; dx <= r && tx < 0; dx++) { int x = PTX() + dx, y = PTY(); if (geto(x, y) == O_TREE && tile_walk(x - 1, y)) { tx = x; ty = y; } }
  if (tx < 0) { tx = PTX() + 2; ty = PTY(); seto(tx, ty, O_TREE); }
  tp(tx - 1, ty); P.dir = 3; P.sel = 0; inv[0].id = 0;
  int w0 = inv_count(I_WOOD);
  step(120, KEY_A);
  CHECK(inv_count(I_WOOD) > w0 && geto(tx, ty) == 0, "minar arbol da madera");
  /* craftear */
  const Recipe *r = &RECIPES[0];
  CHECK(r->out == I_PLANK, "receta 0 = tablon");
  inv_add(I_WOOD, 2); int p0 = inv_count(I_PLANK); do_craft(r);
  CHECK(inv_count(I_PLANK) == p0 + 4, "craftear tablon");
  /* movimiento por casillas */
  tp(70, 70);
  for (int dy = -3; dy <= 3; dy++) for (int dx = -3; dx <= 6; dx++) { seto(70 + dx, 70 + dy, 0); setg(70 + dx, 70 + dy, G_GRASS); }
  P.dir = 0; step(2, 0);
  step(3, KEY_RIGHT);
  CHECK(P.dir == 3 && PTX() == 70, "pulsar una direccion nueva solo gira");
  step(40, KEY_RIGHT);
  step(25, 0);
  CHECK(PTX() >= 72 && PTX() <= 73 && (P.x & 255) == 128 && (P.y & 255) == 128, "al soltar queda alineado a la casilla");
  seto(PTX() + 1, PTY(), O_STONE);
  int bx = PTX(); step(30, KEY_RIGHT); step(5, 0);
  CHECK(PTX() == bx, "un bloque impide el paso");
  /* bote */
  tp(80, 80);
  for (int dy = -4; dy <= 4; dy++) for (int dx = -2; dx <= 12; dx++) { seto(80 + dx, 80 + dy, 0); setg(80 + dx, 80 + dy, (dx >= 2 && dx <= 6) ? G_WATER : G_GRASS); }
  tp(81, 80); P.dir = 3; P.sel = 8; inv[8].id = I_BOAT; inv[8].n = 1; P.cd = 0;
  use_item_b(); step(2, 0);
  CHECK(P.boat == 1 && inv[8].id == 0, "usar el bote mirando al agua embarca");
  step(40, KEY_RIGHT); step(8, 0);
  CHECK(P.boat == 1 && PTX() >= 83 && PTX() <= 86, "el bote navega por el agua");
  step(120, KEY_RIGHT); step(20, 0);
  CHECK(P.boat == 0 && inv_count(I_BOAT) == 1 && PTX() >= 87, "al pisar tierra el bote se guarda");
  /* vuelo en creativo */
  P.mode = MODE_CREATIVE; P.sel = 0;
  tp(81, 82); player_set_fly(1); P.dir = 3; seto(83, 82, O_STONE);
  step(100, KEY_RIGHT); step(20, 0);
  CHECK(P.fly && PTX() >= 86, "volando se pasa sobre agua y bloques");
  player_set_fly(0);
  CHECK(tile_walk(PTX(), PTY()), "al aterrizar queda en una casilla libre");
  P.mode = MODE_SURV; P.fly = 0;
  /* mobs en cuadricula: cuando no se mueven estan centrados en su casilla */
  tp(100, 60);
  for (int dy = -6; dy <= 6; dy++) for (int dx = -6; dx <= 6; dx++) { seto(100 + dx, 60 + dy, 0); setg(100 + dx, 60 + dy, G_GRASS); }
  ents_clear();
  ent_spawn(M_ZOMBIE, 104, 60); ent_spawn(M_COW, 97, 58); ent_spawn(M_PIG, 98, 63);
  int bad = 0;
  for (int f = 0; f < 400; f++) {
    step(1, 0); P.hp = 20;
    for (int i = 0; i < MAXENT; i++) { Ent *e = &ents[i]; if ((e->flags & EF_ALIVE) && !e->stp && ((e->x & 255) != 128 || (e->y & 255) != 128)) bad++; }
  }
  CHECK(bad == 0, "los mobs terrestres solo se detienen en el centro de una casilla");
  /* colocar y portal del Nether */
  tp(60, 60); P.dir = 3;
  int cx = 63, cy = 60;
  for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) { seto(cx + dx, cy + dy, 0); setg(cx + dx, cy + dy, G_GRASS); }
  inv_add(I_OBSIDIAN, 8);
  for (int i = 0; i < INV_N; i++) if (inv[i].id == I_OBSIDIAN) P.sel = (i < 9) ? (u8)i : 0;
  if (inv[P.sel].id != I_OBSIDIAN) { inv[8] = inv[P.sel]; inv[P.sel].id = I_OBSIDIAN; inv[P.sel].n = 8; }
  int placed = 0;
  for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) if (dx || dy) { seto(cx + dx, cy + dy, O_OBS); placed++; }
  tp(cx - 3, cy); P.dir = 3; seto(cx - 2, cy, 0);
  /* el ultimo bloque se coloca con B */
  seto(cx - 1, cy, 0); tp(cx - 3, cy); P.dir = 3; P.sel = P.sel; P.cd = 0;
  P.x = (cx - 2) * 256 + 128; P.y = cy * 256 + 128; P.dir = 3; P.cd = 0;
  step(1, 0); host_keys = 0;
  use_item_b();
  CHECK(geto(cx - 1, cy) == O_OBS, "colocar obsidiana con B");
  CHECK(geto(cx, cy) == O_NPORTAL, "anillo de obsidiana crea portal");
  P.x = cx * 256 + 128; P.y = cy * 256 + 128;
  step(90, 0);
  CHECK(cur_dim == D_NETH, "portal lleva al Nether");
  /* volver */
  P.x = 8 * 256 + 128; P.y = 52 * 256 + 128; step(90, 0);
  CHECK(cur_dim == D_OVER, "portal de regreso");
  /* cuevas */
  P.x = door_pt[0].x * 256 + 128; P.y = door_pt[0].y * 256 + 128; step(3, 0);
  CHECK(cur_dim == D_CAVE, "puerta lleva a las cuevas");
  change_dim(D_OVER, 60, 60);
  /* redstone: palanca + piston */
  for (int y = 55; y < 66; y++) for (int x = 55; x < 66; x++) { seto(x, y, 0); setg(x, y, G_GRASS); }
  seto(58, 60, O_LEVER); seto(59, 60, O_WIRE); seto(60, 60, O_PISTON); wst[tidx(60, 60)] = 3; seto(61, 60, O_COBB);
  rs_neighbor_changed(58, 60); rs_neighbor_changed(60, 60);
  step(20, 0);
  CHECK(geto(61, 60) == O_COBB, "piston sin energia no empuja");
  wst[tidx(58, 60)] |= 0x80; step(30, 0);
  CHECK(geto(61, 60) == O_PHEAD && geto(62, 60) == O_COBB, "palanca+cable activa piston y empuja bloque");
  wst[tidx(58, 60)] &= 0x7F; step(30, 0);
  CHECK(geto(61, 60) == 0, "al apagar, el piston se retrae");
  /* cultivos */
  setg(56, 56, G_SOILW); seto(56, 56, O_WHEAT0);
  for (int i = 0; i < 20000 && geto(56, 56) != O_WHEAT3; i++) { ents_clear(); sim_world(); }
  CHECK(geto(56, 56) == O_WHEAT3, "el trigo crece hasta madurar");
  /* comercio */
  inv_add(I_WHEAT, 10); int e0 = inv_count(I_EMERALD);
  ui_open(MN_TRADE, 0); step(1, 0); step(1, KEY_A); step(1, 0);
  CHECK(inv_count(I_EMERALD) == e0 + 1, "comerciar trigo por esmeralda");
  menu_kind = MN_NONE;
  /* guardar / cargar */
  /* armadura: B equipa y baja el dano */
  Slot keep7 = inv[7];
  inv[7].id = I_IARMOR; inv[7].n = 1; inv[7].dur = 60; inv[7].en = 0; P.sel = 7;
  P.cd = 0; use_item_b();
  CHECK(worn.id == I_IARMOR && inv[7].id == 0, "usar una armadura la equipa");
  CHECK(armor_pct() == ITM[I_IARMOR].a, "la armadura puesta reduce el dano");
  inv[7].id = I_LARMOR; inv[7].n = 1; inv[7].dur = 90; P.sel = 7; P.cd = 0; use_item_b();
  CHECK(worn.id == I_LARMOR && inv[7].id == I_IARMOR, "equipar otra intercambia con la puesta");
  inv[7] = keep7;
  seto(57, 57, O_CHEST); int ci = chest_find(57, 57, 1); chest_inv[ci][0].id = I_DIAMOND; chest_inv[ci][0].n = 5;
  inv_add(I_GOLD, 7); P.lvl = 9; seto(70, 70, O_GOLDB);
  save_game(1);
  P.lvl = 0; inv_take(I_GOLD, 7); seto(70, 70, 0); worn.id = 0;
  CHECK(load_game(1), "cargar partida");
  CHECK(worn.id == I_LARMOR && worn.dur == 90, "guardado conserva la armadura puesta");
  CHECK(P.lvl == 9 && inv_count(I_GOLD) >= 7 && geto(70, 70) == O_GOLDB, "guardado conserva inventario y bloques modificados");
  ci = chest_find(57, 57, 0);
  CHECK(ci >= 0 && chest_inv[ci][0].id == I_DIAMOND, "guardado conserva el cofre");
  /* portal del End: el marco se pisa */
  { int ex = 80, ey = 64; change_dim(D_OVER, ex - 3, ey);
    for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) { setg(ex + dx, ey + dy, G_GRASS); seto(ex + dx, ey + dy, (dx || dy) ? O_FRAMEF : 0); }
    seto(ex - 1, ey, O_FRAME); setg(ex - 2, ey, G_GRASS); seto(ex - 2, ey, 0); setg(ex - 3, ey, G_GRASS);
    CHECK(tile_walk(ex - 1, ey), "el marco del End es transitable");
    tp(ex - 2, ey); P.dir = 3; inv_add(I_EYE, 1);
    for (int i = 0; i < 9; i++) if (inv[i].id == I_EYE) P.sel = (u8)i;
    if (inv[P.sel].id != I_EYE) { inv[6] = (Slot){I_EYE, 1, 0, 0}; P.sel = 6; }
    P.cd = 0; use_item_b();
    CHECK(geto(ex, ey) == O_EPORTAL, "el ultimo ojo abre el portal del End");
    for (int g = 0; g < 80 && PTX() < ex; g++) step(1, KEY_RIGHT);
    step(100, 0);
    CHECK(cur_dim == D_END, "se puede caminar sobre el marco y entrar al portal");
    change_dim(D_OVER, 60, 60); }
  /* camara 3D: las flechas son relativas a la camara */
  { v3d_yawq = 1; step(40, 0); int x0 = PTX(), y0 = PTY(); tp(60, 60); x0 = PTX(); y0 = PTY();
    setg(61, 60, G_GRASS); seto(61, 60, 0); setg(60, 59, G_GRASS); seto(60, 59, 0);
    step(14, KEY_UP);
    CHECK(PTX() == x0 + 1 && PTY() == y0, "con la camara girada 90, arriba en pantalla camina hacia el este");
    v3d_yawq = 0; step(40, 0); }
  /* endermen en overworld y nether */
  { int seen = 0; ents_clear(); day_t = DAY_LEN * 70 / 100;
    for (int k = 0; k < 4000 && !seen; k++) { ents_clear(); game_time = 6; sim_world(); for (int i = 0; i < MAXENT; i++) if ((ents[i].flags & EF_ALIVE) && ents[i].type == M_ENDERMAN) seen = 1; }
    CHECK(seen, "aparecen endermen de noche en el overworld");
    change_dim(D_NETH, spawn_pt[D_NETH].x, spawn_pt[D_NETH].y); int n = 0;
    for (int i = 0; i < MAXENT; i++) if ((ents[i].flags & EF_ALIVE) && ents[i].type == M_ENDERMAN) n++;
    CHECK(n > 0, "hay endermen en el Nether");
    change_dim(D_OVER, 60, 60); }
  /* dragon */
  change_dim(D_END, 24, 38);
  Ent *d = 0; for (int i = 0; i < MAXENT; i++) if (ents[i].type == M_DRAGON && (ents[i].flags & EF_ALIVE)) d = &ents[i];
  CHECK(d != 0, "el dragon aparece en el End");
  if (d) { ent_damage(d, 100, 0, 0); }
  CHECK(P.won && geto(24, 24) == O_XPORTAL, "vencer al dragon abre el portal de salida");
  /* encantar */
  P.lvl = 5; P.sel = 8; inv[8].id = I_ISWORD; inv[8].n = 1; inv[8].en = 0; inv[8].dur = 100; inv_add(I_LAPIS, 3);
  ui_open(MN_ENCH, 0); step(1, 0); step(1, KEY_A); step(1, 0); menu_kind = MN_NONE;
  CHECK(inv[8].en != 0, "mesa de encantamientos encanta la espada");
  printf("%s (%d fallos)\n", fails ? "HAY FALLOS" : "TODO OK", fails);
  return fails != 0;
}
